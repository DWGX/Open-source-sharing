package lynn.utils

import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.particles.Vec3
import java.util.concurrent.atomic.AtomicInteger

/**
 * A simple ring buffer (circular queue) implementation
 * Referenced 'https://gist.github.com/ToxicBakery/05d3d98256aaae50bfbde04ae0c62dbd'
 */
class RingBuffer<T>(val maxCapacity: Int) : Iterable<T> {
    private val array: Array<Any?> = Array(maxCapacity) { null }

    var size = 0
        private set

    private val head
        get() = if (size == maxCapacity) (tail + 1) % size else 0
    private var tail = 0

    fun add(element: T) {
        tail = (tail + 1) % maxCapacity
        array[tail] = element
        if (size < maxCapacity) size++
    }

    operator fun get(index: Int): T? {
        return when {
            size == 0 || index >= size || index < 0 -> null // IndexOOB
            size == maxCapacity -> array[(head + index) % maxCapacity] // Index circulation
            else -> array[index] // Default
        } as? T?
    }

    override fun iterator(): Iterator<T> = object : Iterator<T> {
        private val index: AtomicInteger = AtomicInteger(0)

        override fun hasNext(): Boolean = index.get() < size

        override fun next(): T = get(index.getAndIncrement()) ?: throw NoSuchElementException()
    }
}

data class Location(val position: Vec3, val rotation: Rotation)
