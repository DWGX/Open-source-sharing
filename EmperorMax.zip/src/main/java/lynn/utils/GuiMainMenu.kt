package lynn.utils

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.render.GradientUtil
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.EaseUtils2.easeOutQuart
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.utils.render.blur.GaussianBlur
import net.ccbluex.liquidbounce.utils.render.tenacity.BloomUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiMultiplayer
import net.minecraft.client.gui.GuiScreen
import net.minecraft.client.gui.GuiWorldSelection
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.io.IOException

/**
 *@author =
 *@Date 2022/12/14
 */

class GuiMainMenu : GuiScreen() {
    var mc: Minecraft = Minecraft.getMinecraft()
    var sr: ScaledResolution? = null
    private var progress = 0f
    private var progress2 = 0f
    private var Alt = false
    private var lastMS = 0L
    private var lastMS2 = 0L
    override fun initGui() {
        sr = ScaledResolution(Minecraft.getMinecraft())
        lastMS = System.currentTimeMillis()
        progress = 0f
    }

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        drawBackground(0)
        val sr = ScaledResolution(Minecraft.getMinecraft())
        var length = 2
        val list = LiquidBounce.UPDATE_LIST
        //主界面
        //不知道
        Fonts.font35.drawCenteredString(
            "By:EmperorMax-Team",
            sr.scaledWidth / 2f - 5,
            sr.scaledHeight - 5F - Fonts.font35.fontHeight,
            Color(200, 200, 200).rgb, true
        )
//动画
        progress = if (progress >= 1f) 1f else (System.currentTimeMillis() - lastMS).toFloat() / 2050F
        val trueAnim = easeOutQuart(progress.toDouble())
        GL11.glTranslated(0.0, (1 - trueAnim) * -sr.scaledHeight, 0.0)

        //Logo
        val clientColors = clientColors
        GradientUtil.applyGradientHorizontal(
            (sr.scaledWidth / 2f - 5.0).toFloat(),
            (sr.scaledHeight / 2f - 90.0).toFloat(),
            Fonts.Bnk35.getStringWidth("Emperor").toFloat(), 20f, 1f, clientColors[0], clientColors[1]
        ) {
            RenderUtils.setAlphaLimit(0f)
            BloomUtil.drawAndBloom {
                Fonts.Bnk35.drawCenteredString(
                    "Emperor", (sr.scaledWidth / 2f - 5.0).toFloat(),
                    (sr.scaledHeight / 2f - 90.0).toFloat(), Color(0, 0, 0, 0).rgb
                )
            }
        }
        /* Fonts.Bnk40.drawCenteredString(
                 "EmperorMax",
                 sr.scaledWidth / 2f-5,
                 sr.scaledHeight / 2f - 90,
                 Color(255,255,255).rgb,true )
         */
        GaussianBlur.startBlur()
        RenderUtils.drawRoundedRectfix(50f, 0f, 40.toFloat(), 40f, 1f, Color(0, 0, 0).rgb)
        GaussianBlur.endBlur(20F, 2F)
        //版本号
        RoundedUtil.drawRoundOutline(
            50f,
            -2f,
            40.toFloat(),
            42f,
            1f,
            0.05F,
            Color(240, 240, 240, 18),
            Color(255, 255, 255)
        )
        ShadowUtils.shadow(6f, {
            GL11.glPushMatrix()
            RenderUtils.drawRoundedRectfix(50f, 0f, 40.toFloat(), 40f, 1f, Color(0, 0, 0).rgb)
            GL11.glPopMatrix()
        }, {
            GL11.glPushMatrix()
            GlStateManager.enableBlend()
            GlStateManager.disableTexture2D()
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0)
            RenderUtils.drawRoundedRectfix(50f, 0f, 40.toFloat(), 40f, 1f, Color(0, 0, 0).rgb)
            GlStateManager.enableTexture2D()
            GlStateManager.disableBlend()
            GL11.glPopMatrix()
        })

        Fonts.tenacitybold50.drawCenteredString(
            LiquidBounce.CLIENT_VERSION, 70f, 27f,
            Color(235, 235, 235).rgb, false
        )
        if (RenderUtils.isHovered(50f, 0f, 40.toFloat(), 40f, mouseX, mouseY)) {
            GL11.glTranslated(0.0, (1 - trueAnim) * -sr.scaledHeight, 0.0)
            //更新日志
            for ((i, _: String) in list.withIndex()) {
                length += if (i <= 0) Fonts.font40.fontHeight + 2 else Fonts.font35.fontHeight + 2
            }
            length = 2
            for ((i, _: String) in list.withIndex()) {
                length += if (i <= 0) {
                    Fonts.font35.drawString(list[i], 2F, length.toFloat() + 33, Color(255, 255, 255, 255).rgb, true)
                    Fonts.font35.fontHeight + 2
                } else {
                    Fonts.font35.drawString(list[i], 2F, length.toFloat() + 33, Color(255, 255, 255, 255).rgb, true)
                    Fonts.font35.fontHeight + 2
                }
            }
        }
//阴影
        ShadowUtils.shadow(9f, {
            GL11.glPushMatrix()
            RenderUtils.drawRoundedRectfix(
                sr.scaledWidth / 2f - 90,
                sr.scaledHeight / 2f - 67 - 40,
                (24 + 90 + 10 + 5) + 43.toFloat(),
                (20 * 4 + 7 * 5) + 72.toFloat(),
                12f,
                Color(0, 0, 0).rgb
            )
            GL11.glPopMatrix()
        }, {
            GL11.glPushMatrix()
            GlStateManager.enableBlend()
            GlStateManager.disableTexture2D()
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0)
            RenderUtils.drawRoundedRectfix(
                sr.scaledWidth / 2f - 90,
                sr.scaledHeight / 2f - 67 - 40,
                (24 + 90 + 10 + 5) + 43.toFloat(),
                (20 * 4 + 7 * 5) + 72.toFloat(),
                12f,
                Color(0, 0, 0).rgb
            )
            GlStateManager.enableTexture2D()
            GlStateManager.disableBlend()
            GL11.glPopMatrix()
        })
        //主框
        RoundedUtil.drawRoundOutline(
            sr.scaledWidth / 2f - 90,
            sr.scaledHeight / 2f - 67 - 40,
            (24 + 90 + 10 + 5) + 43.toFloat(),
            (20 * 4 + 7 * 5) + 72.toFloat(),
            12f,
            0.05F,
            Color(240, 240, 240, 12),
            Color(255, 255, 255)
        )
        //单人世界
        var Color = Color(255, 255, 255).rgb
        var a = 0
        if (RenderUtils.isHovered(
                sr.scaledWidth / 2f - 12 - 45 - 5,
                sr.scaledHeight / 2f - 60 + 2,
                (24 + 95).toFloat(),
                25f,
                mouseX,
                mouseY
            )
        ) {
            Color = Color(104, 104, 104).rgb
            a = 18
        }
        RoundedUtil.drawRoundOutline(
            sr.scaledWidth / 2f - 12 - 45 - 10,
            sr.scaledHeight / 2f - 67 + 5,
            (24 + 90 + 10 + 5).toFloat(),
            25.toFloat(),
            12f,
            0.1f,
            Color(240, 240, 240, a),
            Color(255, 255, 255)
        )
        Fonts.font35.drawCenteredString(
            "SinglePlayer", sr.scaledWidth / 2f - 2.5F, sr.scaledHeight / 2f - 55 + 2,
            Color, true
        )
        //f服务器
        var Color2 = Color(255, 255, 255).rgb
        var a2 = 0
        if (RenderUtils.isHovered(
                sr.scaledWidth / 2f - 12 - 45 - 5,
                sr.scaledHeight / 2f - 33 + 5,
                (24 + 90 + 5 + 5).toFloat(),
                20f,
                mouseX,
                mouseY
            )
        ) {
            Color2 = Color(104, 104, 104).rgb
            a2 = 18
        }
        RoundedUtil.drawRoundOutline(
            sr.scaledWidth / 2f - 12 - 45 - 10,
            sr.scaledHeight / 2f - 67 + 20 + 15,
            (24 + 90 + 10 + 5).toFloat(),
            25.toFloat(),
            12f,
            0.1f,
            Color(240, 240, 240, a2),
            Color(255, 255, 255)
        )
        Fonts.font35.drawCenteredString(
            "MultiPlayer", sr.scaledWidth / 2f - 2.5F, sr.scaledHeight / 2f - 13 - 10,
            Color2, true
        )
        //Alts
        var Color4 = Color(255, 255, 255).rgb
        var a3 = 0
        if (RenderUtils.isHovered(
                sr.scaledWidth / 2f - 12 - 45 - 5,
                sr.scaledHeight / 2f - 6 + 8,
                (24 + 90 + 5).toFloat(),
                20f,
                mouseX,
                mouseY
            )
        ) {
            Color4 = Color(104, 104, 104).rgb
            a3 = 18
        }
        RoundedUtil.drawRoundOutline(
            sr.scaledWidth / 2f - 12 - 45 - 10,
            sr.scaledHeight / 2f - 67 + 20 + 45,
            (24 + 90 + 10 + 5).toFloat(),
            25.toFloat(),
            12f,
            0.1f,
            Color(240, 240, 240, a3),
            Color(255, 255, 255)
        )
        Fonts.font35.drawCenteredString(
            "Alts", sr.scaledWidth / 2f - 2.5F, sr.scaledHeight / 2f - 1 + 8,
            Color4, true
        )
        //退出
        var Color5 = Color(255, 255, 255).rgb
        var a4 = 0
        if (RenderUtils.isHovered(
                sr.scaledWidth / 2f - 12 - 45 - 5,
                sr.scaledHeight / 2f + 21 + 12,
                (24 + 90 + 5).toFloat(),
                20f,
                mouseX,
                mouseY
            )
        ) {
            Color5 = Color(104, 104, 104).rgb
            a4 = 18
        }
        RoundedUtil.drawRoundOutline(
            sr.scaledWidth / 2f - 12 - 45 - 10,
            sr.scaledHeight / 2f - 67 + 20 + 75,
            (24 + 90 + 10 + 5).toFloat(),
            25.toFloat(),
            12f,
            0.1f,
            Color(240, 240, 240, a4),
            Color(255, 255, 255)
        )
        Fonts.font35.drawCenteredString(
            "Shutdown", sr.scaledWidth / 2f - 2.5F, sr.scaledHeight / 2f + 26 + 12,
            Color5, true
        )
//测试字体发光
        ShadowUtils.shadow(6f, {
            GL11.glPushMatrix()
            Fonts.font35.drawCenteredString(
                "By:EmperorMax-Team", sr.scaledWidth / 2f - 5, sr.scaledHeight - 5F - Fonts.font35.fontHeight,
                Color(200, 200, 200).rgb, true
            )
            Fonts.tenacitybold50.drawCenteredString(
                LiquidBounce.CLIENT_VERSION, 70f, 27f,
                Color(235, 235, 235).rgb, false
            )

            GL11.glPopMatrix()
        }, {
            GL11.glPushMatrix()
            GlStateManager.enableBlend()
            GlStateManager.disableTexture2D()
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0)
            Fonts.font35.drawCenteredString(
                "By:EmperorMax-Team", sr.scaledWidth / 2f - 5, sr.scaledHeight - 5F - Fonts.font35.fontHeight,
                Color(200, 200, 200).rgb, true
            )
            Fonts.tenacitybold50.drawCenteredString(
                LiquidBounce.CLIENT_VERSION, 70f, 27f,
                Color(235, 235, 235).rgb, false
            )

            GlStateManager.enableTexture2D()
            GlStateManager.disableBlend()
            GL11.glPopMatrix()
        })

    }

    @Throws(IOException::class)
    override fun mouseClicked(mouseX: Int, mouseY: Int, mouseButton: Int) {
        progress = if (progress >= 1f) 1f else (System.currentTimeMillis() - lastMS).toFloat() / 2000F
        val trueAnim = easeOutQuart(progress.toDouble())

        GL11.glTranslated(0.0, (1 - trueAnim) * -height, 0.0)
        //单人世界
        if (RenderUtils.isHovered(
                sr!!.scaledWidth / 2f - 12 - 45 - 5, sr!!.scaledHeight / 2f - 60 + 5, (24 + 95).toFloat(), 25f,
                mouseX, mouseY
            )
        ) {
            Minecraft.getMinecraft().displayGuiScreen(GuiWorldSelection(this))
        }
        //服务器
        if (RenderUtils.isHovered(
                sr!!.scaledWidth / 2f - 12 - 45 - 5, sr!!.scaledHeight / 2f - 33 + 5, (24 + 90 + 5 + 5).toFloat(), 20f,
                mouseX, mouseY
            )
        ) {
            Minecraft.getMinecraft().displayGuiScreen(GuiMultiplayer(this))
        }
//add
        if (RenderUtils.isHovered(
                sr!!.scaledWidth / 2f - 12 - 45 - 5, sr!!.scaledHeight / 2f - 6 + 8, (24 + 90 + 5 - 10).toFloat(), 20f,
                mouseX, mouseY
            )
        ) {
            LiquidBounce.wrapper.minecraft.displayGuiScreen(
                LiquidBounce.wrapper.classProvider.wrapGuiScreen(
                    GuiAltManager()
                )
            )
            Alt = !Alt
        }
        //退出
        if (RenderUtils.isHovered(
                sr!!.scaledWidth / 2f - 12 - 45 - 5, sr!!.scaledHeight / 2f + 21 + 12, (24 + 90 + 5).toFloat(), 20f,
                mouseX, mouseY
            )
        ) {
            Minecraft.getMinecraft().shutdown()
        }
    }

    fun getClientColor(): Color {
        return Color(255, 255, 255)
    }

    fun getAlternateClientColor(): Color {
        return Color(120, 120, 120)
    }

    val hueInterpolation = false
    private fun mixColors(color1: Color, color2: Color): Color {
        return ColorUtil.interpolateColorsBackAndForth(
            15,
            1,
            color1,
            color2,
            hueInterpolation
        )
    }

    private val clientColors: Array<Color>
        get() {
            val firstColor: Color
            val secondColor: Color
            firstColor =
                mixColors(getClientColor(), getAlternateClientColor())
            secondColor =
                mixColors(getAlternateClientColor(), getClientColor())
            return arrayOf(firstColor, secondColor)
        }
}