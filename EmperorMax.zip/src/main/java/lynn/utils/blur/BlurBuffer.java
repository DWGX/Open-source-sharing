package lynn.utils.blur;


import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.features.module.modules.render.BlurSettings;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.blur.KawaseBlur;
import net.minecraft.client.shader.Framebuffer;

import java.awt.*;

public class BlurBuffer {
    private static Framebuffer bloomFramebuffer = new Framebuffer(1, 1, true);

    public static void blurArea(float x, float y, float width, float height) {
        final HUD hud = (HUD) LiquidBounce.moduleManager.getModule(HUD.class);
        StencilUtil.initStencilToWrite();
        RenderUtils.drawRect(x, y, x + width, y + height, new Color(-2).getRGB());
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(BlurSettings.radius.get().floatValue());
        StencilUtil.uninitStencilBuffer();


    }

    public static void blurArea2(float x, float y, float x2, float y2) {
        bloomFramebuffer = RenderUtils.TcreateFrameBuffer(bloomFramebuffer);
        bloomFramebuffer.framebufferClear();
        bloomFramebuffer.bindFramebuffer(false);
        RenderUtils.drawRect(x, y, x + (x2 - x), y + (y2 - y) + 1, new Color(-2).getRGB());
        bloomFramebuffer.unbindFramebuffer();
        KawaseBlur.renderBlur(bloomFramebuffer.framebufferTexture, BlurSettings.iterations.getValue(), BlurSettings.offset.getValue());
    }

    public static void blurAreacustomradius(float x, float y, float width, float height, float radius, float BlurStrength) {
        final HUD hud = (HUD) LiquidBounce.moduleManager.getModule(HUD.class);
        StencilUtil.initStencilToWrite();
        RenderUtils.drawRect(x, y, x + width, y + height, new Color(-2).getRGB());
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(radius);
        GaussianBlur.renderBlur(BlurStrength);
        StencilUtil.uninitStencilBuffer();
    }

    public static void blurRoundArea(float x, float y, float width, float height, int radius) {
        StencilUtil.initStencilToWrite();
        RenderUtils.drawRoundedRect2(x, y, x + width, y + height, radius, 6, new Color(-2).getRGB());
        StencilUtil.readStencilBuffer(1);
        GaussianBlur.renderBlur(8.0F);

        StencilUtil.uninitStencilBuffer();
    }
}
