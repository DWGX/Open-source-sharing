package net.ccbluex.liquidbounce.api.minecraft.util

interface ITimer {
    var timerSpeed: Float
    val renderPartialTicks: Float
}