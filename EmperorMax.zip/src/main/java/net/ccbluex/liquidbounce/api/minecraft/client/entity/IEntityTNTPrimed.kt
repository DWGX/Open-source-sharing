package net.ccbluex.liquidbounce.api.minecraft.client.entity

interface IEntityTNTPrimed : IEntity {
    val fuse: Int
}