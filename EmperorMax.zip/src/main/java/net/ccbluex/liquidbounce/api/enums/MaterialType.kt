package net.ccbluex.liquidbounce.api.enums

enum class MaterialType {
    AIR,
    WATER,
    LAVA
}