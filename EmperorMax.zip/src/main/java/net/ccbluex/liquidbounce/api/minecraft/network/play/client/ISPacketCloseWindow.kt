package net.ccbluex.liquidbounce.api.minecraft.network.play.client

interface ISPacketCloseWindow {
    val windowId: Int
}