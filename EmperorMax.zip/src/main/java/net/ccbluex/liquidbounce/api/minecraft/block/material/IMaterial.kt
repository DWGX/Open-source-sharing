package net.ccbluex.liquidbounce.api.minecraft.block.material

interface IMaterial {
    val isReplaceable: Boolean
}