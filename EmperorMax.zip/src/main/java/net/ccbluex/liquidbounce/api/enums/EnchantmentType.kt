package net.ccbluex.liquidbounce.api.enums

enum class EnchantmentType {
    SHARPNESS,
    POWER,
    PROTECTION,
    FEATHER_FALLING,
    FIRE_ASPECT,
    PROJECTILE_PROTECTION,
    THORNS,
    FIRE_PROTECTION,
    RESPIRATION,
    AQUA_AFFINITY,
    BLAST_PROTECTION,
    UNBREAKING
}