package net.ccbluex.liquidbounce.api.minecraft.util

interface IScaledResolution {
    val scaledWidth: Int
    val scaledHeight: Int
    val scaleFactor: Int
}