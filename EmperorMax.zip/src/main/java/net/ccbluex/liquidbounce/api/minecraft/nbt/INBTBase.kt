package net.ccbluex.liquidbounce.api.minecraft.nbt

interface INBTBase