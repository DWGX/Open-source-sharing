package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import org.lwjgl.opengl.GL11
import org.lwjgl.util.glu.Cylinder
import java.awt.Color

@ModuleInfo(name = "BowAimbot", description = "使用弓时自动瞄准玩家", category = ModuleCategory.COMBAT)
class BowAimbot : Module() {
    private val silentValue = BoolValue("RotationSilent", true)
    private val rotations = ListValue("Rotations", arrayOf("Liquidbounce", "Test", "Test2"), "Test")
    private val predictValue = BoolValue("Predict", true)
    private val throughWallsValue = BoolValue("ThroughWalls", false)
    private val predictSizeValue = FloatValue("PredictSize", 2F, 0.1F, 5F)
    private val priorityValue = ListValue("Priority", arrayOf("Health", "Distance", "Direction"), "Direction")
    private val markValue = ListValue(
        "Mark", arrayOf(
            "Liquid",
            "Block",
            "Red",
            "None"
        ), "Block"
    )

    private var target: IEntity? = null

    override fun onDisable() {
        target = null
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        target = null

        if (classProvider.isItemBow(mc.thePlayer?.itemInUse?.item)) {
            val entity = getTarget(throughWallsValue.get(), priorityValue.get()) ?: return

            target = entity
            if (rotations.get().equals("Test", ignoreCase = true)) {
                RotationUtils.optimizeFaceBow(
                    target, silentValue.get(), predictValue.get(), predictSizeValue.get(),
                    target!!.prevPosX, target!!.prevPosY, target!!.prevPosZ,
                    mc.thePlayer!!.prevPosX, mc.thePlayer!!.prevPosY, mc.thePlayer!!.prevPosZ
                )
            }
            if (rotations.get().equals("Liquidbounce", ignoreCase = true)) {
                RotationUtils.faceBow(target, silentValue.get(), predictValue.get(), predictSizeValue.get())
            }
            if (rotations.get().equals("Test2", ignoreCase = true)) {
                RotationUtils.optimizeFaceBow2(target, silentValue.get(), predictSizeValue.get())
            }
        }
    }

    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        val entity = getTarget(throughWallsValue.get(), priorityValue.get()) ?: return

        when (markValue.get().toLowerCase()) {
            "liquid" -> {
                RenderUtils.drawPlatform(target, Color(37, 126, 255, 170))

            }

            "block" -> {
                RenderUtils.drawEntityBox(target!!, Color.GREEN, true)
            }

            "red" -> {
                RenderUtils.drawPlatform(target, Color(105, 20, 55, 255))
            }

            "sims" -> {
                val radius = 0.15f
                val side = 4
                GL11.glPushMatrix()
                GL11.glTranslated(
                    target!!.lastTickPosX + (target!!.posX - target!!.lastTickPosX) * event.partialTicks - mc.renderManager.viewerPosX,
                    (target!!.lastTickPosY + (target!!.posY - target!!.lastTickPosY) * event.partialTicks - mc.renderManager.viewerPosY) + target!!.height * 1.1,
                    target!!.lastTickPosZ + (target!!.posZ - target!!.lastTickPosZ) * event.partialTicks - mc.renderManager.viewerPosZ
                )
                GL11.glRotatef(-target!!.width, 0.0f, 1.0f, 0.0f)
                GL11.glRotatef((mc.thePlayer!!.ticksExisted + mc.timer.renderPartialTicks) * 5, 0f, 1f, 0f)
                RenderUtils.glColor(Color(80, 255, 80).alpha)
                RenderUtils.enableSmoothLine(1.5F)
                val c = Cylinder()
                GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f)
                c.draw(0F, radius, 0.3f, side, 1)
                c.drawStyle = 100012
                GL11.glTranslated(0.0, 0.0, 0.3)
                c.draw(radius, 0f, 0.3f, side, 1)
                GL11.glRotatef(90.0f, 0.0f, 0.0f, 1.0f)
                GL11.glTranslated(0.0, 0.0, -0.3)
                c.draw(0F, radius, 0.3f, side, 1)
                GL11.glTranslated(0.0, 0.0, 0.3)
                c.draw(radius, 0F, 0.3f, side, 1)
                RenderUtils.disableSmoothLine()
                GL11.glPopMatrix()
            }
        }
    }


    private fun getTarget(throughWalls: Boolean, priorityMode: String): IEntity? {
        val targets = mc.theWorld!!.loadedEntityList.filter {
            classProvider.isEntityLivingBase(it) && EntityUtils.isSelected(it, true) &&
                    (throughWalls || mc.thePlayer!!.canEntityBeSeen(it))
        }

        return when (priorityMode.toUpperCase()) {
            "DISTANCE" -> targets.minBy { mc.thePlayer!!.getDistanceToEntity(it) }
            "DIRECTION" -> targets.minBy { RotationUtils.getRotationDifference(it) }
            "HEALTH" -> targets.minBy { it.asEntityLivingBase().health }
            else -> null
        }
    }

    fun hasTarget() = target != null && mc.thePlayer!!.canEntityBeSeen(target!!)
}