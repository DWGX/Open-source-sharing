/*
 * LiquidBounce+ Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.ResourceLocation


@ModuleInfo(name = "Cape", description = "更好的披风", category = ModuleCategory.RENDER)
class Cape : Module() {

    val styleValue =
        ListValue("Style", arrayOf("Lunar", "Bilibili", "LiquidBounce", "JiaRan", "RQ", "Bilibilitv"), "loserline")

    fun getCapeLocation(value: String): ResourceLocation {
        return try {
            CapeStyle.valueOf(value.toUpperCase()).location
        } catch (e: IllegalArgumentException) {
            CapeStyle.LIQUIDBOUNCE.location
        }
    }

    enum class CapeStyle(val location: ResourceLocation) {
        LUNAR(ResourceLocation("dwgx/cape/lunar.png")),
        BILIBILI(ResourceLocation("dwgx/cape/biliBili.png")),
        LIQUIDBOUNCE(ResourceLocation("dwgx/cape/LiquidBounce.png")),
        JIARAN(ResourceLocation("dwgx/cape/jiaran.png")),
        RQ(ResourceLocation("dwgx/cape/rq.png")),
        BILIBILITV(ResourceLocation("dwgx/cape/bilibilitv.png")),
    }

    override val tag: String
        get() = styleValue.get()
}