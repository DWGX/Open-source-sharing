/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.font.FontLoaders
import net.ccbluex.liquidbounce.utils.render.AnimationUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import java.awt.Color
import kotlin.math.pow

@ModuleInfo(
    name = "HUD",
    description = "Toggles visibility of the HUD.",
    category = ModuleCategory.RENDER,
    array = false
)
class HUD : Module() {
    private val toggleMessageValue = BoolValue("DisplayToggleMessage", true)
    private val toggleSoundValue = ListValue("ToggleSound", arrayOf("None", "Default", "Custom"), "Custom")
    private val colorRedValue = IntegerValue("R", 255, 0, 255)
    private val colorGreenValue = IntegerValue("G", 255, 0, 255)
    private val colorBlueValue = IntegerValue("B", 255, 0, 255)
    val ChineseScore = BoolValue("ChineseScore ", true)
    val fontChatValue = BoolValue("FontChat", false)
    val chatRect = BoolValue("ChatRect", false)
    val chatAnimValue = BoolValue("ChatAnimation", true)
    val blackHotbarValue = BoolValue("BlackHotbar", true)
    val blackHotbarblur = BoolValue("BlackHotbarBlur", true)

    @JvmField
    val hotbar = BoolValue("Hotbar", false)
    val hotbarEaseValue = BoolValue("HotbarEase", true)
    val hueInterpolation = BoolValue("HueInterpolate", false)
    val inventoryParticle = BoolValue("InventoryParticle", false)
    private var easingxp: Float = 0F
    private var hotBarX = 0F
    private var easingValue = 0
    val animHotbarValue = BoolValue("AnimatedHotbar", true)
    fun getAnimPos(pos: Float): Float {
        if (state && animHotbarValue.get()) hotBarX =
            AnimationUtils.animate(pos, hotBarX, 0.02F * RenderUtils.deltaTime.toFloat())
        else hotBarX = pos

        return hotBarX
    }

    companion object {
        val clolormode = ListValue(
            "ColorMode", arrayOf(
                "Rainbow",
                "Light Rainbow",
                "Static",
                "Double Color",
                "Default"
            ), "Light Rainbow"
        )
    }

    private fun fix() {
        GlStateManager.resetColor()
    }

    @EventTarget
    fun onTick(event: TickEvent) {
        LiquidBounce.moduleManager.shouldNotify = toggleMessageValue.get()
        LiquidBounce.moduleManager.toggleSoundMode = toggleSoundValue.values.indexOf(toggleSoundValue.get())
    }

    @EventTarget
    fun onShader(event: ShaderEvent?) {
        if (classProvider.isGuiHudDesigner(mc.currentScreen))
            return

        LiquidBounce.hud.renderShader(false)
    }

    val sr = ScaledResolution(mc2)
    val left: Int = sr.scaledWidth / 2 + 91
    val top: Int = sr.scaledHeight - 100
    val x = 380

    @EventTarget
    fun onRender2D(event: Render2DEvent?) {

        if (classProvider.isGuiHudDesigner(mc.currentScreen))
            return
        val sr = ScaledResolution(mc2)
        val left = sr.scaledWidth / 2 + 91
        val top = sr.scaledHeight - 50
        val x = left - 1 * 8 - 180
        val scaledResolution = ScaledResolution(mc2)

        if (hotbar.get() && mc.thePlayer != null && mc.theWorld != null) {
            var color2 = Color(50, 50, 50, 255).rgb
            var color = Color(190, 28, 3)


            if (mc.thePlayer!!.isPotionActive(classProvider.getPotionEnum(PotionType.REGENERATION))) {
                color2 = Color(50, 50, 50, 255).rgb
                color = Color(254, 13, 107)
            }
            RoundedUtil.drawRound(x.toFloat() - 1, top.toFloat(), 100F, 12f, 2f, Color(color2))
            RoundedUtil.drawRound(
                x.toFloat() - 1,
                top.toFloat(),
                (mc.thePlayer!!.health / 20f) * 100F,
                12f,
                2f,
                color
            )
            FontLoaders.C18.drawString(
                "HP " + String.format("%.1f", mc.thePlayer!!.health) + " | 20.0",
                x.toFloat() + 3, ((top + 7 - FontLoaders.C18.FONT_HEIGHT / 2).toFloat()) + 3.5f,
                -1
            )
            RoundedUtil.drawRound(x.toFloat() - 1, top.toFloat() - 3f - 15f - 1, 101f, 13f, 2f, Color(50, 50, 50, 255))
            RoundedUtil.drawRound(
                x.toFloat() - 1,
                top.toFloat() - 3f - 15f - 1,
                (mc2.player.totalArmorValue / 20f) * 101F,
                13f,
                2f,
                Color(66, 148, 252)
            )
            FontLoaders.C18.drawString(
                "Armor " + (mc2.player.totalArmorValue).toString() + " | 20",
                x.toFloat() + 3,
                ((top + 7 - FontLoaders.C18.FONT_HEIGHT / 2).toFloat()) - 3f - 15f + 2.8f,
                -1
            )

            RoundedUtil.drawRound(
                x.toFloat() + 110F - 1,
                top.toFloat() - 3f - 15f - 1,
                101f,
                13f,
                2f,
                Color(50, 50, 50, 255)
            )
            RoundedUtil.drawRound(
                x.toFloat() + 110F - 1,
                top.toFloat() - 3f - 15f - 1,
                easingxp,
                13f,
                2f,
                Color(34, 151, 59)
            )
            FontLoaders.C18.drawString(
                "EXP " + mc2.player.experienceLevel.toString(),
                x.toFloat() + 110F + 3,
                ((top + 7 - FontLoaders.C18.FONT_HEIGHT / 2).toFloat()) - 3f - 15f + 3f,
                -1
            )
            RoundedUtil.drawRound(x.toFloat() + 110F - 1, top.toFloat(), 100f, 12f, 2f, Color(50, 50, 50, 255))
            RoundedUtil.drawRound(
                x.toFloat() + 110F - 1,
                top.toFloat(),
                (mc2.player.foodStats.foodLevel / 20F) * 100F,
                12f,
                2f,
                Color(208, 116, 32)
            )
            FontLoaders.C18.drawString(
                "Food " + (mc2.player.foodStats.foodLevel).toString() + " | 20",
                x.toFloat() + 110F + 3,
                ((top + 7 - FontLoaders.C18.FONT_HEIGHT / 2).toFloat()) + 3.5f,
                -1
            )
            easingxp += ((mc2.player.experience * 100F) - easingxp) / 2.0F.pow(10.0F - 5F) * RenderUtils.deltaTime

        }

        LiquidBounce.hud.render(false)

    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }

    fun getClientColors(): Array<Color> {
        val firstColor: Color
        val secondColor: Color
        when (clolormode.get().toLowerCase()) {
            "light rainbow" -> {
                firstColor = ColorUtil.rainbow(15, 1, .6f, 1F, 1F)
                secondColor = ColorUtil.rainbow(15, 40, .6f, 1F, 1F)
            }

            "rainbow" -> {
                firstColor = ColorUtil.rainbow(15, 1, 1F, 1F, 1F)
                secondColor = ColorUtil.rainbow(15, 40, 1F, 1F, 1F)
            }

            "double color" -> {
                firstColor =
                    ColorUtil.interpolateColorsBackAndForth(15, 0, Color.PINK, Color.BLUE, hueInterpolation.get())
                secondColor =
                    ColorUtil.interpolateColorsBackAndForth(15, 90, Color.PINK, Color.BLUE, hueInterpolation.get())
            }

            "static" -> {
                firstColor = Color(colorRedValue.get(), colorGreenValue.get(), colorBlueValue.get())
                secondColor = firstColor
            }

            else -> {
                firstColor = Color(-1)
                secondColor = Color(-1)
            }
        }
        return arrayOf(firstColor, secondColor)
    }

    fun getHotbarEasePos(x: Int): Int {
        if (!state || !hotbarEaseValue.get()) return x
        easingValue = x
        return easingValue
    }

    private fun onArmor(target: IEntityLivingBase) {
    }

    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }

    @EventTarget(ignoreCondition = true)
    fun onScreen(event: ScreenEvent) {
        if (mc.theWorld == null || mc.thePlayer == null) return
        if (state && !mc.entityRenderer.isShaderActive() && event.guiScreen != null &&
            !(classProvider.isGuiChat(event.guiScreen) || classProvider.isGuiHudDesigner(event.guiScreen))
        ) mc.entityRenderer.loadShader(classProvider.createResourceLocation("liquidbounce" + "/blur.json")) else if (mc.entityRenderer.shaderGroup != null &&
            mc.entityRenderer.shaderGroup!!.shaderGroupName.contains("emperormax/blur.json")
        ) mc.entityRenderer.stopUseShader()
    }

    init {
        state = true
    }
}