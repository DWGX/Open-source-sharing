package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.event.ShaderEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.render.RoundedUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

@ModuleInfo(name = "CustomHUD", description = "CustomHUD.", category = ModuleCategory.RENDER)
public class CustomHUD extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static ScaledResolution sr = new ScaledResolution(mc);

    public CustomHUD() {
        setState(true);
    }

    @EventTarget
    public void onShader(final ShaderEvent event) {
        sr = new ScaledResolution(mc);
        if (LiquidBounce.getHeight() != -14) {
            RoundedUtil.drawRound(6, sr.getScaledHeight() - ((LiquidBounce.getHeight() + 63)), 340,
                    LiquidBounce.getHeight() + 10, 2,
                    new Color(0, 0, 0, 60));
        }
    }

    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        sr = new ScaledResolution(mc);
        if (LiquidBounce.getHeight() != -14) {
            RoundedUtil.drawRound(6, sr.getScaledHeight() - ((LiquidBounce.getHeight() + 63)), 340,
                    LiquidBounce.getHeight() + 10, 2,
                    new Color(0, 0, 0, 60));
        }
    }
}
