package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.SPacketChat
import java.util.regex.Pattern

@ModuleInfo(name = "AntiName", description = "反玩家虚假名称", category = ModuleCategory.HYT)
class AntiName : Module() {
    val modeValue = ListValue("Mode", arrayOf("4v4", "16and32"), "4v4")

    override fun onDisable() {
        clearAll()
        super.onDisable()
    }

    @EventTarget
    fun onWorld(event: WorldEvent?) {
        clearAll()
    }

    private fun clearAll() {
        LiquidBounce.fileManager.friendsConfig.clearFriends()
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is SPacketChat) {
            when (modeValue.get().toLowerCase()) {
                "4v4" -> {
                    val message = Pattern.compile("起床战争>> (.*?)|杀死了 (.*?)\\(")
                        .matcher(packet.chatComponent.unformattedText)
                    val message2 = Pattern.compile("起床战争>> (.*?) (\\((((.*?)死了!)))")
                        .matcher(packet.chatComponent.unformattedText)
                    if (message.find()) {
                        val name = message.group(1).trim()
                        if (name != "") {
                            LiquidBounce.fileManager.friendsConfig.addFriend(name)
                            ClientUtils.displayChatMessage("§7[§cAntiBot§7]>> §f添加无敌人：§a" + name)
                            Thread {
                                try {
                                    Thread.sleep(5000)
                                    LiquidBounce.fileManager.friendsConfig.removeFriend(name)
                                    ClientUtils.displayChatMessage("§7[§cAntiBot§7]>> §f删除无敌人：§a" + name)
                                } catch (ex: InterruptedException) {
                                    ex.printStackTrace()
                                }
                            }.start()
                        }
                    }
                    if (message2.find()) {
                        val name = message2.group(1).trim()
                        if (name != "") {
                            LiquidBounce.fileManager.friendsConfig.addFriend(name)
                            ClientUtils.displayChatMessage("§7[§cAntiBot§7]>> §f添加无敌人：§a" + name)
                            Thread {
                                try {
                                    Thread.sleep(5000)
                                    LiquidBounce.fileManager.friendsConfig.removeFriend(name)
                                    ClientUtils.displayChatMessage("§7[§cAntiBot§7]>> §f删除无敌人：§a" + name)
                                } catch (ex: InterruptedException) {
                                    ex.printStackTrace()
                                }
                            }.start()
                        }
                    }
                }

                "16and32" -> {
                    val message = Pattern.compile("击败了 (.*?)!").matcher(packet.chatComponent.unformattedText)
                    val message2 = Pattern.compile("玩家 (.*?)死了！").matcher(packet.chatComponent.unformattedText)
                    if (message.find()) {
                        val name = message.group(1).trim()
                        if (name != "") {
                            LiquidBounce.fileManager.friendsConfig.addFriend(name)
                            ClientUtils.displayChatMessage("§fAntiBot§7>> §f添加无敌人：§a" + name)
                            Thread {
                                try {
                                    Thread.sleep(10000)
                                    LiquidBounce.fileManager.friendsConfig.removeFriend(name)
                                    ClientUtils.displayChatMessage("§fAntiBot§7>> §f删除无敌人：§a" + name)
                                } catch (ex: InterruptedException) {
                                    ex.printStackTrace()
                                }
                            }.start()
                        }
                    }
                    if (message2.find()) {
                        val name = message2.group(1).trim()
                        if (name != "") {
                            LiquidBounce.fileManager.friendsConfig.addFriend(name)
                            ClientUtils.displayChatMessage("§fAntiBot§7>> §f添加无敌人：§a" + name)
                            Thread {
                                try {
                                    Thread.sleep(10000)
                                    LiquidBounce.fileManager.friendsConfig.removeFriend(name)
                                    ClientUtils.displayChatMessage("§fAntiBot§7>> §f删除无敌人：§a" + name)
                                } catch (ex: InterruptedException) {
                                    ex.printStackTrace()
                                }
                            }.start()
                        }
                    }
                }
            }
        }
    }
}