package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(
    name = "ComponentOnHover",
    description = "允许您在悬停时查看聊天消息组件的点击操作和值",
    category = ModuleCategory.MISC
)
class ComponentOnHover : Module()