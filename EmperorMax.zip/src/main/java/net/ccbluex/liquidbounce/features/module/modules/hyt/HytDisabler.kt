package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.player.InventoryCleaner
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.Packet
import net.minecraft.network.play.client.CPacketClickWindow
import net.minecraft.network.play.client.CPacketEntityAction
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
import java.util.concurrent.LinkedBlockingQueue

@ModuleInfo(name = "HytDisabler", description = "new hyt", category = ModuleCategory.HYT)
class HytDisabler : Module() {

    private val c0e = BoolValue("ChestStealer", false)
    private val c08 = BoolValue("PlaceBlock", false)
    private val c0b = BoolValue("C0B", false)
    private val fastBreak = BoolValue("fastBreak", false)
    private val Spartan = BoolValue("Spartan", false)


    private var blockPos: WBlockPos? = null
    private var enumFacing: IEnumFacing? = null
    private var pre = false
    private val packets = LinkedBlockingQueue<Packet<*>>()


    @EventTarget
    fun onUpdate() {
        val inventoryCleaner = LiquidBounce.moduleManager[InventoryCleaner::class.java] as InventoryCleaner
        if (inventoryCleaner.state) {
            c0e.set(true)
        } else {
            c0e.set(false)
        }
        if (Spartan.get()) {
            mc.gameSettings.keyBindJump.pressed = false
            mc.thePlayer!!.motionY *= 0.2
            mc.thePlayer!!.onGround = true
            mc.timer.timerSpeed = 0.2f
            LiquidBounce.commandManager.executeCommands(".hclip 8")
        }
    }

    @EventTarget
    fun onMotion(event: MotionEvent) {
        pre = event.eventState == EventState.PRE

        if (event.eventState == EventState.PRE) {
            try {
                while (!packets.isEmpty()) {
                    mc2.connection!!.networkManager.sendPacket(packets.take())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is CPacketClickWindow && c0e.get()) {
            if (!pre) {
                event.cancelEvent()
                packets.add(packet)
            }
        }
        if (packet is CPacketEntityAction && c0b.get()) {
            if (!pre) {
                event.cancelEvent()
                packets.add(packet)
            }
        }
        if (packet is CPacketPlayerTryUseItemOnBlock && c08.get()) {
            if (!pre) {
                event.cancelEvent()
                packets.add(packet)
            }
        }
    }

    @EventTarget
    fun onClickBlock(event: ClickBlockEvent) {
        blockPos = event.clickedBlock ?: return
        enumFacing = event.WEnumFacing ?: return
        if (fastBreak.get()) {
            mc.netHandler.addToSendQueue(
                classProvider.createCPacketPlayerDigging(
                    ICPacketPlayerDigging.WAction.ABORT_DESTROY_BLOCK,
                    blockPos!!,
                    enumFacing!!
                )
            )
        }
    }

    override val tag: String
        get() = "Grim"
}