package net.ccbluex.liquidbounce.features.module.modules.hyt

import lynn.utils.PacketUtils
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.enums.WEnumHand
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.EventState
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.SlowDownEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.Backend.MINECRAFT_VERSION_MINOR
import net.ccbluex.liquidbounce.injection.backend.WrapperImpl
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.CPacketConfirmTransaction
import net.minecraft.network.play.client.CPacketPlayer
import java.util.*

@ModuleInfo(
    name = "HytNoSlow", description = "Bypass Hyt",
    category = ModuleCategory.HYT

)
class HYTNoSlow : Module() {

    private val modeValue = ListValue(
        "PacketMode",
        arrayOf("Hyt-Normal", "Hyt-Full", "Hyt-Vanilla", "Hyt-Fast", "Hyt-Legit"),
        "Hyt-Vanilla"
    )
    private val timer = MSTimer()
    private var pendingFlagApplyPacket = false
    private val msTimer = MSTimer()
    private var sendBuf = false
    private var packetBuf = LinkedList<Packet<INetHandlerPlayServer>>()
    private var nextTemp = false
    private var waitC03 = false
    private var packet = 0
    override fun onDisable() {
        timer.reset()
        msTimer.reset()
        pendingFlagApplyPacket = false
        sendBuf = false
        packetBuf.clear()
        nextTemp = false
        waitC03 = false
    }

    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (!MovementUtils.isMoving) {
            return
        }
        when (modeValue.get().toLowerCase()) {
            "hyt-normal" -> {
                if ((event.eventState == EventState.PRE && mc.thePlayer!!.itemInUse != null && mc.thePlayer!!.itemInUse!!.item != null) && !mc.thePlayer!!.isBlocking && classProvider.isItemFood(
                        mc.thePlayer!!.heldItem!!.item
                    ) || classProvider.isItemPotion(mc.thePlayer!!.heldItem!!.item)
                ) {
                    if (mc.thePlayer!!.onGround) {
                        if (mc.thePlayer!!.isUsingItem && mc.thePlayer!!.itemInUseCount >= 1) {
                            if (mc.thePlayer!!.sprinting) {
                                if (!mc.thePlayer!!.onGround) {
                                    mc.thePlayer!!.sprinting = false
                                }
                            }
                            mc.thePlayer!!.sprinting = mc.thePlayer!!.ticksExisted % 2 != 0
                            return
                        }
                    }
                }
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.timer.timerSpeed = 1.0F
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }

            "hyt-fast" -> {
                if ((event.eventState == EventState.PRE && mc.thePlayer!!.itemInUse != null && mc.thePlayer!!.itemInUse!!.item != null) && !mc.thePlayer!!.isBlocking && classProvider.isItemFood(
                        mc.thePlayer!!.heldItem!!.item
                    ) || classProvider.isItemPotion(mc.thePlayer!!.heldItem!!.item)
                ) {
                    if (mc.thePlayer!!.isUsingItem && mc.thePlayer!!.itemInUseCount >= 1) {
                        if (mc.thePlayer!!.sprinting) {
                            if (!mc.thePlayer!!.onGround) {
                                mc.thePlayer!!.sprinting = false
                            }
                        }
                        if (packet != 16) {
                            if (mc.thePlayer!!.ticksExisted % 2 == 0) {
                                mc.thePlayer!!.sprinting = false
                                mc.timer.timerSpeed = 0.33f
                            } else {
                                mc.thePlayer!!.sprinting = true
                                mc.timer.timerSpeed = 0.9F
                            }
                            PacketUtils.sendPacketNoEvent(CPacketPlayer(true))
                            return
                        }
                    }
                }
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.timer.timerSpeed = 1.0F
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }

            "hyt-legit" -> {
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }

            "hyt-full" -> {
                /*
                when (event.eventState) {
                    EventState.PRE -> {
                        thePlayerisBlocking = false
                        val digging = classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                        mc.netHandler.addToSendQueue(digging)
                        thePlayerisBlocking = true
                    }

                    EventState.POST -> {
                        thePlayerisBlocking = false
                        mc2.connection!!.networkManager.sendPacket(CPacketConfirmTransaction())
                        val blockPlace1 =
                            createUseItemPacket(mc.thePlayer!!.inventory.getCurrentItemInHand(), WEnumHand.MAIN_HAND)
                        val blockPlace2 =
                            createUseItemPacket(mc.thePlayer!!.inventory.getCurrentItemInHand(), WEnumHand.OFF_HAND)
                        if (LiquidBounce.moduleManager[Animations::class.java].state) {
                            mc.netHandler.addToSendQueue(blockPlace2)
                        } else {
                            mc.netHandler.addToSendQueue(blockPlace1)
                            mc.netHandler.addToSendQueue(blockPlace2)
                        }
                        thePlayerisBlocking = true


                    }
                    */

                val item = mc.thePlayer!!.heldItem!!.item != null && mc.thePlayer!!.isUsingItem
                        && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)
                val blockPlace1 =
                    createUseItemPacket(mc.thePlayer!!.inventory.getCurrentItemInHand(), WEnumHand.MAIN_HAND)
                val blockPlace2 =
                    createUseItemPacket(mc.thePlayer!!.inventory.getCurrentItemInHand(), WEnumHand.OFF_HAND)

                if (event.eventState == EventState.PRE && item) {
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                }
                if (event.eventState == EventState.POST && item) {
                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(blockPlace1)
                    mc.netHandler.addToSendQueue(blockPlace2)
                }
            }

            "hyt-vanilla" -> {
                mc.thePlayer!!.motionX = mc.thePlayer!!.motionX
                mc.thePlayer!!.motionY = mc.thePlayer!!.motionY
                mc.thePlayer!!.motionZ = mc.thePlayer!!.motionZ
            }
        }
    }

    fun createUseItemPacket(itemStack: IItemStack?, hand: WEnumHand): IPacket {
        return if (MINECRAFT_VERSION_MINOR == 8) {
            WrapperImpl.classProvider.createCPacketPlayerBlockPlacement(itemStack)
        } else {
            WrapperImpl.classProvider.createCPacketTryUseItem(hand)
        }
    }

    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item

        event.forward = getMultiplier(heldItem, true)
        event.strafe = getMultiplier(heldItem, false)
    }

    private fun getMultiplier(item: IItem?, isForward: Boolean): Float {
        if (modeValue.get() == "Hyt-Vanilla") {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 0.55F else 0.55F
                }

                else -> 0.2F
            }
        }
        if (modeValue.get() == "Hyt-Normal") {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }

                else -> 0.6F
            }
        }
        if (modeValue.get() == "Hyt-Fast") {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }

                else -> 0.79F
            }
        } else {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }

                else -> 0.2F
            }
        }
    }

    override val tag: String
        get() = modeValue.get()

}


