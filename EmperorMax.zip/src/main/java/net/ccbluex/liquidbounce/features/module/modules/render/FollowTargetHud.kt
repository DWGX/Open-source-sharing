/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.ShaderEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils.*
import net.ccbluex.liquidbounce.utils.render.blur.BlurUtils
import net.ccbluex.liquidbounce.value.*
import net.minecraft.client.renderer.GlStateManager.resetColor
import net.minecraft.entity.EntityLivingBase
import org.lwjgl.opengl.GL11.*
import java.awt.Color
import java.text.DecimalFormat
import kotlin.math.roundToInt

@ModuleInfo(name = "FollowTargetHud", description = "跟随目标显示", category = ModuleCategory.RENDER)
class FollowTargetHud : Module() {
    private val zoomIn = BoolValue("ZoomIn", true)
    private val modeValue =
        ListValue("Mode", arrayOf("Juul", "Jello", "Material", "Material2", "Arris", "FDP"), "Arris")
    private val fontValue = FontValue("Font", Fonts.font40)
    private val materialShadow =
        BoolValue("MaterialShadow", false).displayable { modeValue.equals("Material") || modeValue.equals("Material2") }
    private val fdpVertical = BoolValue("FDPVertical", false).displayable { modeValue.equals("FDP") }
    private val fdpText = BoolValue("FDPDrawText", true).displayable { modeValue.equals("FDP") && !fdpVertical.get() }
    private val fdpRed = BoolValue("FDPRed", false).displayable { modeValue.equals("FDP") }
    private val test = BoolValue("test", true)
    private val blur = BoolValue("Blur", false)

    // Shadow
    private val Shadow = BoolValue("Shadow", false)
    private val jelloColorValue = BoolValue("JelloHPColor", true).displayable { modeValue.equals("Jello") }
    private val jelloAlphaValue = IntegerValue("JelloAlpha", 170, 0, 255).displayable { modeValue.equals("Jello") }
    private val scaleValue = FloatValue("Scale", 1F, 1F, 4F)
    private val translateY = FloatValue("TanslateY", 0.55F, -2F, 2F)
    private val translateX = FloatValue("TranslateX", 0F, -2F, 2F)
    private var xChange = translateX.get() * 20

    private var targetTicks = 0
    private var entityKeep = "yes"


    companion object {
        val HEALTH_FORMAT = DecimalFormat("#.#")
    }

    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        if (mc.thePlayer == null)
            return
        for (entity in mc.theWorld!!.loadedEntityList) {
            if (EntityUtils.isSelected(entity, false)) {
                renderNameTag(entity.asEntityLivingBase(), (entity.displayName ?: continue).unformattedText)
            }
        }
    }

    private fun getPlayerName(entity: EntityLivingBase): String {
        val name = entity.displayName.formattedText
        return name
    }


    private fun renderNameTag(entity: IEntityLivingBase, tag: String) {
        xChange = translateX.get() * 20

        val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        if (entity != killAura.target) {
            return
        } else if (entity == killAura.target) {
            entityKeep = entity.name.toString()
            targetTicks++
            if (targetTicks >= 5) {
                targetTicks = 4
            }
        } else if (killAura.target == null) {
            targetTicks--
            if (targetTicks <= -1) {
                targetTicks = 0
                entityKeep = "dg636 top"
            }
        }

        if (targetTicks == 0) {
            return
        }

        // Set fontrenderer local
        val fontRenderer = fontValue.get()
        val font = Fonts.font30

        // Push
        glPushMatrix()

        // Translate to player position
        val renderManager = mc.renderManager
        val timer = mc.timer

        glTranslated( // Translate to player position with render pos and interpolate it
            entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * timer.renderPartialTicks - renderManager.renderPosX,
            entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * timer.renderPartialTicks - renderManager.renderPosY + entity.eyeHeight.toDouble() + translateY.get()
                .toDouble(),
            entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * timer.renderPartialTicks - renderManager.renderPosZ
        )

        // Rotate view to player
        glRotatef(-mc.renderManager.playerViewY, 0F, 1F, 0F)
        glRotatef(mc.renderManager.playerViewX, 1F, 0F, 0F)

        // Scale
        var distance = mc.thePlayer!!.getDistanceToEntity(entity) / 4F

        if (distance < 1F) {
            distance = 1F
        }

        val scale = (distance / 150F) * scaleValue.get()

        // Disable lightning and depth test
        disableGlCap(GL_LIGHTING, GL_DEPTH_TEST)

        // Enable blend
        enableGlCap(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        val name = entity.displayName!!.unformattedText
        var healthPercent = entity.health / entity.maxHealth
        // render hp bar
        if (healthPercent > 1) {
            healthPercent = 1F
        }

        // Draw nametag
        when (modeValue.get().toLowerCase()) {


            "juul" -> {

                // render bg
                glScalef(-scale * 2, -scale * 2, scale * 2)
                drawRoundedCornerRect(-120f + xChange, -16f, -50f + xChange, 10f, 5f, Color(64, 64, 64, 255).rgb)
                drawRoundedCornerRect(-110f + xChange, 0f, -20f + xChange, 35f, 5f, Color(96, 96, 96, 255).rgb)

                // draw strings
                fontRenderer.drawString("Attacking", -105 + xChange.toInt(), -13, Color.WHITE.rgb)
                fontRenderer.drawString(tag, -106 + xChange.toInt(), 10, Color.WHITE.rgb)


                val distanceString =
                    "⤢" + (((mc.thePlayer!!.getDistanceToEntity(entity) * 10f).toInt()).toFloat() * 0.1f).toString()
                fontRenderer.drawString(
                    distanceString,
                    -25 - fontRenderer.getStringWidth(distanceString).toInt() + xChange.toInt(),
                    10,
                    Color.WHITE.rgb
                )

                // draw health bars
                drawRoundedCornerRect(-104f + xChange, 22f, -50f + xChange, 30f, 1f, Color(64, 64, 64, 255).rgb)
                drawRoundedCornerRect(
                    -104f + xChange,
                    22f,
                    -104f + (healthPercent * 54) + xChange,
                    30f,
                    1f,
                    Color.WHITE.rgb
                )

            }

            "material" -> {
                glScalef(-scale * 2, -scale * 2, scale * 2)

                // render bg
                if (materialShadow.get()) {
                    drawShadow(-40f + xChange, 0f, 40f + xChange, 29f)
                    drawRect(-40f + xChange, 0f, 40f + xChange, 29f, Color(72, 72, 72, 250).rgb)
                } else {
                    drawRoundedCornerRect(-40f + xChange, 0f, 40f + xChange, 29f, 5f, Color(72, 72, 72, 250).rgb)
                }

                // draw health bars
                drawRoundedCornerRect(
                    -35f + xChange,
                    7f,
                    -35f + (healthPercent * 70) + xChange,
                    12f,
                    2f,
                    Color(10, 250, 10, 255).rgb
                )
                drawRoundedCornerRect(
                    -35f + xChange,
                    17f,
                    -35f + ((entity.totalArmorValue / 20F) * 70) + xChange,
                    22f,
                    2f,
                    Color(10, 10, 250, 255).rgb
                )

            }

            "material2" -> {
                glScalef(-scale * 2, -scale * 2, scale * 2)

                // render bg
                if (materialShadow.get()) {
                    drawShadow(-40f + xChange, 0f, 40f + xChange, 15f)
                    drawShadow(-40f + xChange, 0f, 20f + xChange, 35f)

                    drawRect(-40f + xChange, 0f, 40f + xChange, 15f, Color(72, 72, 72, 250).rgb)
                    drawRect(-40f + xChange, 20f, 40f + xChange, 35f, Color(72, 72, 72, 250).rgb)
                } else {
                    drawRoundedCornerRect(-40f + xChange, 0f, 40f + xChange, 15f, 5f, Color(72, 72, 72, 250).rgb)
                    drawRoundedCornerRect(-40f + xChange, 20f, 40f + xChange, 35f, 5f, Color(72, 72, 72, 250).rgb)
                }

                // draw health bars
                drawRoundedCornerRect(
                    -35f + xChange,
                    5f,
                    -35f + (healthPercent * 70) + xChange,
                    10f,
                    2f,
                    Color(10, 250, 10, 255).rgb
                )
                drawRoundedCornerRect(
                    -35f + xChange,
                    25f,
                    -35f + ((entity.totalArmorValue / 20F) * 70) + xChange,
                    30f,
                    2f,
                    Color(10, 10, 250, 255).rgb
                )

            }

            "arris" -> {
                glScalef(-scale * 1, -scale * 1, scale * 1)
                val x = if (test.get()) {
                    (classProvider.createScaledResolution(mc).scaledWidth / 2) - xChange
                } else {
                    (classProvider.createScaledResolution(mc).scaledWidth / 2) - xChange
                }
                val y = if (test.get()) {
                    (classProvider.createScaledResolution(mc).scaledHeight / 2) - 0f
                } else {
                    (classProvider.createScaledResolution(mc).scaledHeight / 2) - (entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * timer.renderPartialTicks - renderManager.renderPosY + entity.eyeHeight.toDouble() + translateY.get()
                        .toDouble()).toFloat()
                }
                val hp = healthPercent
                val additionalWidth = font.getStringWidth("${entity.name}  $hp hp").coerceAtLeast(75)


                //
                drawRoundedCornerRect(xChange, 0f, 45f + additionalWidth + xChange, 40f, 7f, Color(0, 0, 0, 110).rgb)
                if (blur.get()) {
                    glTranslated(-x.toDouble(), -y.toDouble(), 0.0)
                    glPushMatrix()
                    BlurUtils.CustomBlurRoundAreaz(x + xChange, y + 0f, 45f + additionalWidth + xChange, 40f, 7f, 30f)
                    glPopMatrix()
                    glTranslated(x.toDouble(), y.toDouble(), 0.0)
                }
                // info text
                font.drawString(entity.name!!, 40 + xChange.toInt(), 5, Color.WHITE.rgb)
                "${HEALTH_FORMAT.format(entity.health)} hp".also {
                    font.drawString(
                        it,
                        40 + additionalWidth - font.getStringWidth(it) + xChange.toInt(),
                        5,
                        Color.LIGHT_GRAY.rgb
                    )
                }
                // hp bar
                val yPos = 5 + font.fontHeight + 3f
                drawRect(
                    40f + xChange,
                    yPos,
                    40 + xChange + (healthPercent) * additionalWidth,
                    yPos + 4,
                    Color.GREEN.rgb
                )
                drawRect(
                    40f + xChange,
                    yPos + 9,
                    40 + xChange + (entity.totalArmorValue / 20F) * additionalWidth,
                    yPos + 13,
                    Color(77, 128, 255).rgb
                )

            }

            "fdp" -> {

                val font = fontValue.get()
                glScalef(-scale * 2, -scale * 2, scale * 2)

                if (!fdpVertical.get()) {
                    var addedLen = (60 + font.getStringWidth(entity.name!!) * 1.60f).toFloat()
                    if (!fdpText.get()) addedLen = 110f

                    if (fdpRed.get()) {
                        drawRect(0f + xChange, 0f, addedLen + xChange, 47f, Color(212, 63, 63, 90).rgb)
                        drawRoundedCornerRect(
                            0f + xChange,
                            0f,
                            healthPercent * addedLen + xChange,
                            47f,
                            3f,
                            Color(245, 52, 27, 90).rgb
                        )
                    } else {
                        drawRect(0f + xChange, 0f, addedLen + xChange, 47f, Color(0, 0, 0, 120).rgb)
                        drawRoundedCornerRect(
                            0f + xChange,
                            0f,
                            healthPercent * addedLen + xChange,
                            47f,
                            3f,
                            Color(0, 0, 0, 90).rgb
                        )
                    }

                    drawShadow(0f, 0f, addedLen + xChange, 47f)

                    if (fdpText.get()) {

                        fontRenderer.drawString(entity.name!!, 45 + xChange.toInt(), 8, Color.WHITE.rgb)
                        fontRenderer.drawString(
                            "Health ${entity.health.roundToInt()}",
                            45 + xChange.toInt(),
                            11 + (font.fontHeight).toInt(),
                            Color.WHITE.rgb
                        )
                    }
                } else {
                    if (fdpRed.get()) {
                        drawRect(
                            0f + xChange,
                            0f,
                            47f + xChange,
                            120f + xChange,
                            Color(212, 63, 63, 90).rgb
                        )
                        drawRoundedCornerRect(
                            healthPercent * 120f + xChange,
                            0f,
                            47f + xChange,
                            0f,
                            3f,
                            Color(245, 52, 27, 90).rgb
                        )
                    } else {
                        drawRect(0f + xChange, 0f, 47f + xChange, 120f, Color(0, 0, 0, 120).rgb)
                        drawRoundedCornerRect(
                            0f + xChange,
                            0f,
                            47f + xChange,
                            healthPercent * 120f,
                            3f,
                            Color(0, 0, 0, 90).rgb
                        )
                    }
                }

            }

            "jello" -> {
                // colors
                var hpBarColor = Color(255, 255, 255, jelloAlphaValue.get())
                val name = entity.displayName!!.unformattedText
                if (jelloColorValue.get() && name.startsWith("§")) {
                    hpBarColor = ColorUtils.colorCode(name.substring(1, 2), jelloAlphaValue.get())
                }
                val bgColor = Color(50, 50, 50, jelloAlphaValue.get())
                val width = fontRenderer.getStringWidth(tag)
                val maxWidth = (width + 4F) - (-width - 4F)
                var healthPercent = entity.health / entity.maxHealth

                // render bg
                glScalef(-scale * 2, -scale * 2, scale * 2)
                drawRect(xChange, -fontRenderer.fontHeight * 3F, width + 8F + xChange, -3F, bgColor)

                // render hp bar
                if (healthPercent > 1) {
                    healthPercent = 1F
                }

                drawRect(xChange, -3F, maxWidth * healthPercent + xChange, 1F, hpBarColor)
                drawRect(maxWidth * healthPercent + xChange, -3F, width + 8F + xChange, 1F, bgColor)

                // string
                fontRenderer.drawString(tag, 4 + xChange.toInt(), -fontRenderer.fontHeight * 2 - 4, Color.WHITE.rgb)
                glScalef(0.5F, 0.5F, 0.5F)
                fontRenderer.drawString(
                    "Health: " + entity.health.toInt(),
                    4 + xChange.toInt(),
                    -fontRenderer.fontHeight * 2,
                    Color.WHITE.rgb
                )
            }
        }
        // Reset caps
        resetCaps()

        // Reset color
        resetColor()
        glColor4f(1F, 1F, 1F, 1F)

        // Pop
        glPopMatrix()
    }

    @EventTarget
    fun onShader(event: ShaderEvent?) {
        val entity: IEntityLivingBase = mc.thePlayer!!
        xChange = translateX.get() * 20
        val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        if (entity != killAura.target) {
            return
        } else if (entity == killAura.target) {
            entityKeep = entity.name.toString()
            targetTicks++
            if (targetTicks >= 5) {
                targetTicks = 4
            }
        } else if (killAura.target == null) {
            targetTicks--
            if (targetTicks <= -1) {
                targetTicks = 0
                entityKeep = "dg636 top"
            }
        }

        if (targetTicks == 0) {
            return
        }

        val font = Fonts.font30
        // Push
        glPushMatrix()

        // Translate to player position
        val renderManager = mc.renderManager
        val timer = mc.timer

        glTranslated( // Translate to player position with render pos and interpolate it
            entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * timer.renderPartialTicks - renderManager.renderPosX,
            entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * timer.renderPartialTicks - renderManager.renderPosY + entity.eyeHeight.toDouble() + translateY.get()
                .toDouble(),
            entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * timer.renderPartialTicks - renderManager.renderPosZ
        )

        // Rotate view to player
        glRotatef(-mc.renderManager.playerViewY, 0F, 1F, 0F)
        glRotatef(mc.renderManager.playerViewX, 1F, 0F, 0F)

        // Scale
        var distance = mc.thePlayer!!.getDistanceToEntity(entity) / 4F

        if (distance < 1F) {
            distance = 1F
        }

        val scale = (distance / 150F) * scaleValue.get()

        // Disable lightning and depth test
        disableGlCap(GL_LIGHTING, GL_DEPTH_TEST)

        // Enable blend
        enableGlCap(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        val name = entity.displayName!!.unformattedText
        var healthPercent = entity.health / entity.maxHealth
        // render hp bar
        if (healthPercent > 1) {
            healthPercent = 1F
        }

        // Draw nametag
        when (modeValue.get().toLowerCase()) {

            "arris" -> {
                glScalef(-scale * 1, -scale * 1, scale * 1)
                val hp = healthPercent
                val additionalWidth = font.getStringWidth("${entity.name}  $hp hp").coerceAtLeast(75)
                //
                drawRoundedCornerRect(xChange, 0f, 45f + additionalWidth + xChange, 40f, 7f, Color(0, 0, 0, 110).rgb)
            }
        }
        // Reset caps
        resetCaps()
        // Reset color
        resetColor()
        glColor4f(1F, 1F, 1F, 1F)
        // Pop
        glPopMatrix()
    }

}
