package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "NoClickDelay", description = "来自FDPClient5.3.5的NoClickDelay", category = ModuleCategory.COMBAT)
class NoClickDelay : Module()