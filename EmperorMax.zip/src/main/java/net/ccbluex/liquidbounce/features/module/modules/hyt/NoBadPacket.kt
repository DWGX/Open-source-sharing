package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.client.CPacketEntityAction
import net.minecraft.network.play.client.CPacketHeldItemChange

@ModuleInfo("NoBadPacket", "SK1D by Heyan", ModuleCategory.HYT)//改掉你妈妈也就消失了 转1.12.2真tm烦
class NoBadPacket : Module() {
    private val c09 = BoolValue("C09Fix", false)
    private val c0B = BoolValue("C0BFix", false)

    //c09
    private var c09Sent = false
    private var lastC09 = 0

    //c0b
    private var lastAction = ""
    private var canSprint = false

    //当关闭时
    override fun onDisable() {

    }

    //当开启时
    override fun onEnable() {

    }


    @EventTarget
    fun onWorld(event: WorldEvent) {
        lastAction = ""
        c09Sent = false
    }


    //当攻击时
    @EventTarget
    fun onAttack(event: AttackEvent) {

    }

    //当minecraft玩家更新时
    @EventTarget
    fun onUpdate(event: UpdateEvent) {

    }

    //当minecraft玩家更新行走时
    @EventTarget
    fun onMotion(event: MotionEvent) {

    }

    //当接收或发送数据包时
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (c09.get()) {
            if (packet is CPacketHeldItemChange && !c09Sent) {
                c09Sent = true
                lastC09 = packet.slotId
            }
            if (c09Sent) {
                if (packet is CPacketHeldItemChange) {
                    if (packet.slotId == lastC09) {
                        event.cancelEvent()
                    } else {
                        lastC09 = packet.slotId
                    }
                }
            }
        }
        if (c0B.get()) {
            canSprint =
                !(!MovementUtils.isMoving || (mc.thePlayer!!.movementInput.moveForward < 0.8f || mc.thePlayer!!.isInLava || mc.thePlayer!!.isInWater || mc.thePlayer!!.isInWeb || mc.thePlayer!!.isOnLadder))

            if (packet is CPacketEntityAction) {


                if (packet.action.name == lastAction) {
                    event.cancelEvent()
                } else {
                    if (!canSprint && packet.action == CPacketEntityAction.Action.START_SPRINTING) {
                        event.cancelEvent()
                    } else {
                        lastAction = packet.action.name
                    }
                }
            }

        }

    }

    //每时每刻(可能不标准)
    @EventTarget
    fun onTick(event: TickEvent) {

    }

    //移动或飞行时(可能不标准)
    @EventTarget
    fun onStrafe(event: StrafeEvent) {

    }

}