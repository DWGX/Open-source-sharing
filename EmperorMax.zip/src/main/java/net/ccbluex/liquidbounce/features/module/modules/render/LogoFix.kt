package net.ccbluex.liquidbounce.features.module.modules.render

import lynn.utils.ShadowUtils
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.ShaderEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.font1.CFontRenderer
import net.ccbluex.liquidbounce.ui.client.font1.FontLoaders
import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.render.DrRenderUtils
import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.render.GradientUtil
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.ServerUtils
import net.ccbluex.liquidbounce.utils.misc.MathUtils
import net.ccbluex.liquidbounce.utils.novoline.ScaleUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.BloomUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil
import net.ccbluex.liquidbounce.value.*
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.util.ResourceLocation
import org.lwjgl.input.Keyboard
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.hypot
import kotlin.math.roundToLong

@ModuleInfo(name = "LogoFix", description = ":)", category = ModuleCategory.RENDER, keyBind = Keyboard.KEY_G)
class LogoFix : Module() {
    val logoValue = ListValue(
        "Logo",
        arrayOf("New", "Outline", "Emperor", "Neverlose", "Neverlose2", "Fluger", "Novoline", "Jello"),
        "Neverlose2"
    )
    private val colorMode = ListValue("LogoColorMode", arrayOf("Rainbow", "Light Rainbow", "Gident"), "Gident")
    private val clientName = TextValue("ClientName", "Emperor")
    val infoValue = BoolValue("Info", true)
    val sColors = BoolValue("Colors", true)
    val hueInterpolation = BoolValue("hueInterpolation", false)
    private val novoshadow = BoolValue("Shadow", true)
    private val shadowValue = FloatValue("ShadowStrength", 10f, 0f, 20f)
    var r = IntegerValue("r", 160, 0, 255)
    var g = IntegerValue("b", 50, 0, 255)
    var b = IntegerValue("g", 255, 0, 255)
    private val bottomLeftText: MutableMap<String, String> = LinkedHashMap()
    private var gradientColor1 = Color.WHITE
    private var gradientColor2: Color? = Color.WHITE
    private var gradientColor3: Color? = Color.WHITE
    private var gradientColor4: Color? = Color.WHITE
    val shadowNoCutValue = true
    private var firstColor = Color.BLACK
    private var secondColor: Color? = Color.BLACK
    private var thirdColor: Color? = Color.BLACK
    private var fourthColor: Color? = Color.BLACK

    @EventTarget
    fun onShader(event: ShaderEvent?) {
        firstColor = ColorUtil.interpolateColorsBackAndForth(
            15, 0, getClientColor(), getAlternateClientColor(),
            hueInterpolation.get()
        )
        secondColor = ColorUtil.interpolateColorsBackAndForth(
            15, 90, getClientColor(), getAlternateClientColor(),
            hueInterpolation.get()
        )
        thirdColor = ColorUtil.interpolateColorsBackAndForth(
            15, 180, getClientColor(), getAlternateClientColor(),
            hueInterpolation.get()
        )
        fourthColor = ColorUtil.interpolateColorsBackAndForth(
            15, 270, getClientColor(), getAlternateClientColor(),
            hueInterpolation.get()
        )
        when (logoValue.get().toLowerCase()) {
            "neverlose2" -> {
                var timeB: String? = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                val xe =
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.Newuiicon.Newuiicon116.Newuiicon116.stringWidth(
                        "d"
                    ) +
                            net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                                mc2.getSession().username
                            )
                val xee = xe + FontLoaders.ICON18.getStringWidth("Q") + 5
                val xeee =
                    xee + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                        EntityUtils.getPing(mc.thePlayer!!).toString()
                    ) + 3
                val xeeee = xeee +
                        FontLoaders.ICONS18.getStringWidth("f") + 4
                val xeees = xeeee +
                        net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                            Minecraft.getDebugFPS().toString()
                        ) + 2
                val xeeess = xeees +
                        FontLoaders.HICONS18.getStringWidth("B") - 1
                val x =
                    xeeess + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                        timeB
                    ) + 20
                RenderUtils.drawRoundedRect2(6F, 5F, 48f, 15F, 6F, Color(0, 0, 0).rgb)
                GlStateManager.resetColor()
                RenderUtils.drawRoundedRect2(60F, 5F, 8 + x.toFloat(), 15F, 6F, Color(0, 0, 0).rgb)
                GlStateManager.resetColor()
            }

            "neverlose" -> {
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                RenderUtils.drawRoundedRect2(
                    6F, 0.toFloat() + 5F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                            + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" | $username | $servername | $times | $fps")
                            + 3F + 5F,
                    12F, 2F, Color(0, 0, 0).rgb
                )
                GlStateManager.resetColor()
            }

            "novoline" -> {
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                val x1 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("| ") + 1
                val x2 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$username") + 3
                val x3 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 3
                val x4 =
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$servername") - 1
                val x5 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 3
                val x6 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$times") + 6
                val x7 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 2
                val x8 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$fps") + 3
                RenderUtils.drawRoundedRect2(
                    6F,
                    0.toFloat() + 5F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                            + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + 7F,
                    12F,
                    0F,
                    Color(0, 0, 0).rgb
                )
                GlStateManager.resetColor()
            }

            "outline" -> {
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                if (BlurSettings.logoGlow.get()) {
                    RoundedUtil.drawGradientRound(
                        4.7F, 6F,
                        net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                                + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" §8| §f$username §8| §f$servername §8| §f$times §8| §f$fps")
                                + 3F + 6F - 0.4f, 11.2F, 4F,
                        ColorUtil.applyOpacity(fourthColor, 1f), firstColor, secondColor, thirdColor
                    )
                } else {
                    RoundedUtil.drawRound(
                        4.7F, 6F,
                        net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                                + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" §8| §f$username §8| §f$servername §8| §f$times §8| §f$fps")
                                + 3F + 6F - 0.4f, 11.2F, 4F,
                        Color(0, 0, 0)
                    )
                }
                GlStateManager.resetColor()
            }

            "new" -> {
                GradientUtil.applyGradientHorizontal(
                    5f,
                    5f,
                    FontLoaders.T40.getStringWidth(clientName.get()).toFloat(),
                    20f,
                    1f,
                    clientColors[0],
                    clientColors[1]
                ) {
                    RenderUtils.setAlphaLimit(0F)
                    BloomUtil.drawAndBloom {
                        FontLoaders.T40.drawStringWithShadow(
                            clientName.get(), 5.0, 5.0, Color(0, 0, 0, 0).rgb
                        )
                    }
                }
                GlStateManager.resetColor()
                FontLoaders.T18.drawString(
                    LiquidBounce.CLIENT_VERSIO, (FontLoaders.T40.getStringWidth(clientName.get()) + 4).toFloat(), 5f,
                    clientColors[1].rgb
                )

            }
        }

        if (infoValue.get()) {
            drawInfo(clientColors)
        }
    }

    private fun drawInfo(clientColors: Array<Color>) {
        val sr = ScaledResolution(Minecraft.getMinecraft())
        bottomLeftText["XYZ:"] = mc.thePlayer!!.posX.roundToLong()
            .toString() + " " + mc.thePlayer!!.posY.roundToLong() + " " + mc.thePlayer!!.posZ.roundToLong()
        bottomLeftText["Speed:"] = calculateBPS().toString()
        bottomLeftText["FPS:"] = Minecraft.getDebugFPS().toString()
        val yOffset = 0.toFloat()
        val height = ((FontLoaders.SF18.height + 2) * bottomLeftText.keys.size).toFloat()
        val width = FontLoaders.SF18.getStringWidth("XYZ:").toFloat()
        GradientUtil.applyGradientVertical(
            2f,
            sr.scaledHeight - (height + yOffset),
            width,
            height,
            1f,
            clientColors[0],
            clientColors[1]
        ) {
            RenderUtils.setAlphaLimit(0F)
            var boldFontMovement = FontLoaders.SF18.height + 2 + yOffset
            for ((key, value) in bottomLeftText) {
                BloomUtil.drawAndBloom {
                    FontLoaders.SF18.drawString(key + value, 2f, sr.scaledHeight - boldFontMovement, -1)
                }
                boldFontMovement += (FontLoaders.SF18.height + 2).toFloat()
            }
        }

        val text = String.format(LiquidBounce.CLIENT_NAME + "-" + LiquidBounce.CLIENT_VERSION)
        GradientUtil.applyGradientHorizontal(
            ((classProvider.createScaledResolution(mc).scaledWidth - FontLoaders.SF18.getStringWidth(text) - 1).toFloat()),
            (((classProvider.createScaledResolution(mc).scaledHeight - FontLoaders.SF18.height - 1).toFloat())),
            FontLoaders.SF18.getStringWidth(text).toFloat(), 9f, 1f, clientColors[0], clientColors[1]
        ) {
            RenderUtils.setAlphaLimit(0f)
            BloomUtil.drawAndBloom {
                FontLoaders.SF18.drawString(
                    text,
                    (classProvider.createScaledResolution(mc).scaledWidth - FontLoaders.SF18.getStringWidth(text) - 1).toDouble()
                        .toFloat(),
                    ((classProvider.createScaledResolution(mc).scaledHeight - FontLoaders.SF18.height - 1).toDouble()
                        .toFloat()),
                    -1
                )
            }
        }

    }


    private fun calculateBPS(): Double {
        val bps = hypot(
            mc.thePlayer!!.posX - mc.thePlayer!!.prevPosX,
            mc.thePlayer!!.posZ - mc.thePlayer!!.prevPosZ
        ) * mc.timer.timerSpeed * 20
        return (bps * 100.0).roundToLong() / 100.0
    }

    @EventTarget
    fun onRender2D(event: Render2DEvent?) {

        val sigmaY = 4
        val sigmaX = 8
        // PlayTime
        val clientColors = clientColors
        when (logoValue.get().toLowerCase()) {
            "outline" -> {
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)

                RoundedUtil.drawRound(
                    4.7F, 6F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                            + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" §8| §f$username §8| §f$servername §8| §f$times §8| §f$fps")
                            + 3F + 6F - 0.4f, 11.2F, 4F,
                    Color(0, 0, 0, 50)
                )
                GlStateManager.resetColor()
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    "Emperor",
                    6,
                    8,
                    -1
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    " §8| §f$username §8| §f$servername §8| §f$times §8| §f$fps",
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + 9,
                    9,
                    -1
                )
                ScaleUtils.drawOutline2(
                    8f,
                    5.1F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" §8| §f$username §8| §f$servername §8| §f$times §8| §f$fps") + 85f,
                    9.2F,
                    4f,
                    2.4F,
                    -2f
                )
            }

            "neverlose2" -> {
                var timeB: String? = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                val xe =
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.Newuiicon.Newuiicon116.Newuiicon116.stringWidth(
                        "d"
                    ) +
                            net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                                mc2.getSession().username
                            )

                val xee = xe + FontLoaders.ICON18.getStringWidth("Q") + 5
                val xeee =
                    xee + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                        EntityUtils.getPing(mc.thePlayer!!).toString()
                    ) + 3


                val xeeee = xeee +
                        FontLoaders.ICONS18.getStringWidth("f") + 4

                val xeees = xeeee +
                        net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                            Minecraft.getDebugFPS().toString()
                        ) + 2

                val xeeess = xeees +
                        FontLoaders.HICONS18.getStringWidth("B") - 1


                val x =
                    xeeess + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.stringWidth(
                        timeB
                    ) + 20

                RoundedUtil.drawRound(
                    6F, 5F, 48F, 15F, 5F,
                    Color(0, 20, 40, 215)
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    "Emperor", 9, 10,
                    Color(24, 114, 165).rgb
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    "Emperor",
                    8,
                    10,
                    -1
                )
//
                RoundedUtil.drawRound(
                    60F, 5F, 8 + x.toFloat(), 15F, 5F,
                    Color(0, 20, 40, 215)
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.Newuiicon.Newuiicon116.Newuiicon116.drawString(
                    "d",
                    62,
                    11.5.toInt(),
                    Color(6, 180, 255).rgb
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.drawString(
                    mc2.getSession().username, 72, 11.5.toInt(), Color(255, 255, 255).rgb
                )

                FontLoaders.ICON18.drawString("Q", 69.5f + xe, 10.8f, Color(6, 180, 255).rgb)
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.drawString(
                    EntityUtils.getPing(mc.thePlayer!!).toString() + " ms",
                    67 + xee,
                    11.5.toInt(),
                    Color(255, 255, 255).rgb
                )

                FontLoaders.ICONS18.drawString("f", 80f + xeee, 11f, Color(6, 180, 255).rgb)
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.drawString(
                    Minecraft.getDebugFPS().toString(), 79 + xeeee, 11.5.toInt(), Color(255, 255, 255).rgb
                )

                FontLoaders.HICONS18.drawString("B", 80.1f + xeees, 11f, Color(6, 180, 255).rgb)
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_15.SFBOLD_15.drawString(
                    timeB, 83 + xeeess, 11.5.toInt(), Color(255, 255, 255).rgb
                )
                GlStateManager.resetColor()
            }

            "fluger" -> {
                var animationA: Int = 0
                var animate: Boolean = false
                var xA: Float = 10.0f
                var yA: Float = 10.0f
                var heightA: Float = 10.0f
                var timeB: String? = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                var user: String? = mc.session.username
                var textA: String? = "Emperor | Time: $timeB | User: $user"
                var textWidth: Int =
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth(textA)
                var widthA: Float = (textWidth + 11).toFloat()
                if (animationA >= 255) {
                    animate = true
                }

                if (animationA <= 0) {
                    animate = false
                }
                if (animate) {
                    --animationA
                }
                if (!animate) {
                    ++animationA
                }
                val hud = LiquidBounce.moduleManager.getModule(HUD::class.java) as HUD
                gradientColor1 = RenderUtils.interpolateColorsBackAndForth(
                    15,
                    0,
                    getClientColor(),
                    getAlternateClientColor(),
                    hud.hueInterpolation.get()
                )
                gradientColor2 = RenderUtils.interpolateColorsBackAndForth(
                    15,
                    90,
                    getClientColor(),
                    getAlternateClientColor(),
                    hud.hueInterpolation.get()
                )
                gradientColor3 = RenderUtils.interpolateColorsBackAndForth(
                    15,
                    180,
                    getClientColor(),
                    getAlternateClientColor(),
                    hud.hueInterpolation.get()
                )
                gradientColor4 = RenderUtils.interpolateColorsBackAndForth(
                    15,
                    270,
                    getClientColor(),
                    getAlternateClientColor(),
                    hud.hueInterpolation.get()
                )
                animationA = MathUtils.clamp_int(animationA, 0, 255)
                RoundedUtil.drawGradientRound(
                    xA,
                    yA,
                    widthA,
                    heightA,
                    4.0f,
                    DrRenderUtils.applyOpacity(gradientColor4, .85f), gradientColor1, gradientColor3, gradientColor2
                )
                GlStateManager.resetColor()
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    textA,
                    xA + 5.0f,
                    yA + 2.5f,
                    -1
                )
            }

            "Emperor" -> {
                val hudMod = LiquidBounce.moduleManager.getModule(HUD::class.java) as HUD
                val gradientColor1 = RenderUtils.interpolateColorsBackAndForth(
                    15, 0, getClientColor(), getAlternateClientColor(),
                    hudMod.hueInterpolation.get()
                )
                val gradientColor2 = RenderUtils.interpolateColorsBackAndForth(
                    15, 90, getClientColor(), getAlternateClientColor(),
                    hudMod.hueInterpolation.get()
                )
                val gradientColor3 = RenderUtils.interpolateColorsBackAndForth(
                    15, 180, getClientColor(), getAlternateClientColor(),
                    hudMod.hueInterpolation.get()
                )
                val gradientColor4 = RenderUtils.interpolateColorsBackAndForth(
                    15, 270, getClientColor(), getAlternateClientColor(),
                    hudMod.hueInterpolation.get()
                )
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                if (novoshadow.get()) {
                    GL11.glTranslated((-0.toFloat()).toDouble(), (-0.toFloat()).toDouble(), 0.0)
                    GL11.glScalef(1F, 1F, 1F)
                    GL11.glPushMatrix()
                    ShadowUtils.shadow(shadowValue.get(), {
                        GL11.glPushMatrix()
                        GL11.glTranslated(0.toFloat() + 6.0, 0.toFloat().toDouble(), 0.0)
                        GL11.glScalef(1F, 1F, 1F)
                        RoundedUtil.newdrawGradientRounde(
                            0F,
                            0.toFloat() + 5F,
                            net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(
                                " | $username | $servername | $times | $fps"
                            ) + 3F + 5F,
                            12F,
                            4F,
                            DrRenderUtils.applyOpacity(gradientColor4, 1f),
                            gradientColor1,
                            gradientColor3,
                            gradientColor2
                        )
                        GL11.glPopMatrix()

                    }, {
                        if (!shadowNoCutValue) {
                            GL11.glPushMatrix()
                            GL11.glTranslated(0.toFloat().toDouble(), 0.toFloat().toDouble(), 0.0)
                            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0)
                            RoundedUtil.newdrawGradientRounde(
                                6F,
                                0.toFloat() + 5F,
                                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth(
                                    "Emperor"
                                ) + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" | $username | $servername | $times | $fps") + 3F + 5F,
                                12F,
                                4F,
                                DrRenderUtils.applyOpacity(gradientColor4, 1f),
                                gradientColor1,
                                gradientColor3,
                                gradientColor2
                            )
                            GL11.glPopMatrix()
                        }
                    })
                    GL11.glPopMatrix()
                    GL11.glScalef(1F, 1F, 1F)
                    GL11.glTranslated(0.toFloat().toDouble(), 0.toFloat().toDouble(), 0.0)
                }

                RoundedUtil.drawRound(
                    6F,
                    0.toFloat() + 5F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(
                        " | $username | $servername | $times | $fps"
                    ) + 3F + 5F,
                    12F,
                    4F,
                    Color(0, 0, 0, 210)
                )
                GlStateManager.resetColor()
                GradientUtil.applyGradientHorizontal(
                    9f,
                    9f,
                    FontLoaders.SF16.getStringWidth(clientName.get()).toFloat(),
                    20f,
                    1f,
                    clientColors[1],
                    clientColors[0]
                ) {
                    RenderUtils.setAlphaLimit(0f)
                    BloomUtil.drawAndBloom {
                        FontLoaders.SF16.drawStringWithShadow(
                            clientName.get(), 9.0,
                            9.0, Color(0, 0, 0, 0).rgb
                        )
                    }
                }
                GlStateManager.resetColor()
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "| $username | $servername | $times | $fps",
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + 11,
                    9,
                    -1
                )
                GL11.glTranslated((-0.toFloat()).toDouble(), (-0.toFloat()).toDouble(), 0.0)
                GL11.glPushMatrix()
                ShadowUtils.shadow(5f, {
                    GL11.glPushMatrix()
                    GL11.glTranslated(0.toFloat() + 6.0, 0.toFloat().toDouble(), 0.0)
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                        "| $username | $servername | $times | $fps",
                        net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + 11 - 5,
                        9,
                        -1
                    )
                    GL11.glPopMatrix()
                }, {})
                GL11.glPopMatrix()
                GL11.glTranslated(0.toFloat().toDouble(), 0.toFloat().toDouble(), 0.0)
            }

            "neverlose" -> {
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)

                RoundedUtil.drawRound(
                    6F, 5F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                            + net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth(" | $username | $servername | $times | $fps")
                            + 3F + 5F, 12F, 2F,
                    Color(0, 0, 0, 100)
                )
                GlStateManager.resetColor()

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    "Emperor",
                    9,
                    7,
                    Color(24, 114, 165).rgb
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString(
                    "Emperor",
                    8,
                    7,
                    -1
                )
                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    " | $username | $servername | $times | $fps",
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor") + 11,
                    8,
                    -1
                )
            }

            "new" -> {
                GradientUtil.applyGradientHorizontal(
                    5f,
                    5f,
                    FontLoaders.T40.getStringWidth(clientName.get()).toFloat(),
                    20f,
                    1f,
                    clientColors[0],
                    clientColors[1]
                ) {
                    RenderUtils.setAlphaLimit(0F)
                    BloomUtil.drawAndBloom {
                        FontLoaders.T40.drawStringWithShadow2(clientName.get(), 5.0, 5.0, Color(0, 0, 0, 0).rgb)
                    }
                }
                GlStateManager.resetColor()
                FontLoaders.T18.drawString(
                    LiquidBounce.CLIENT_VERSIO, (FontLoaders.T40.getStringWidth(clientName.get()) + 4).toFloat(), 5f,
                    clientColors[1].rgb
                )

            }

            "jello" -> {
                val fr: CFontRenderer = FontLoaders.jellolight18

                RenderUtils.drawShadowImage(
                    sigmaX - 12 - fr.getStringWidth("Emperor") / 2 - 8,
                    sigmaY + 1,
                    125,
                    50,
                    ResourceLocation("emperormax/shadow/arraylistshadow.png")
                )
                GlStateManager.resetColor()
                FontLoaders.jellolightBig.drawString("Emperor", 8.0F, 4.0F + 1f, Color(255, 255, 255, 130).rgb)
                FontLoaders.jellolight18.drawCenteredString(
                    "Jello",
                    8.0 + 10,
                    4.0 + 28,
                    Color(255, 255, 255, 170).rgb
                )
            }

            "novoline" -> {
                val counter = intArrayOf(0)
                var username: String? = mc.session.username
                var servername: String? = ServerUtils.getRemoteIp()
                var fps: String? = Minecraft.getDebugFPS().toString() + "fps"
                val times = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                val x1 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("| ") + 1
                val x2 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$username") + 3
                val x3 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 3
                val x4 =
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$servername") - 1
                val x5 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 3
                val x6 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$times") + 6
                val x7 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("|") + 2
                val x8 = net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.stringWidth("$fps") + 3
                RenderUtils.drawRoundedRect2(
                    6F,
                    0.toFloat() + 5F,
                    net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth("Emperor")
                            + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + 7F,
                    12F,
                    0F,
                    Color(0, 0, 0, 100).rgb
                )
                val startX = 6 // 设置起始位置
                for (i in 0..(AColorPalette.gradientLoopValue.get() - 1)) {
                    val barStart = startX + i.toDouble() / AColorPalette.gradientLoopValue.get()
                        .toDouble() * (net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth(
                        "Emperor"
                    ) + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + 7F)
                    val barEnd = startX + (i + 1).toDouble() / AColorPalette.gradientLoopValue.get()
                        .toDouble() * (net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.stringWidth(
                        "Emperor"
                    ) + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + 7F)
                    RenderUtils.drawGradientSideways(
                        barStart,
                        4.toDouble(),
                        0 + barEnd,
                        5.0,
                        getColorAtIndex(i),
                        getColorAtIndex(i + 1)
                    )
                }
                GradientUtil.applyGradientHorizontal(
                    9f,
                    9f,
                    FontLoaders.SF16.getStringWidth(clientName.get()).toFloat(),
                    20f,
                    1f,
                    clientColors[1],
                    clientColors[0]
                ) {
                    RenderUtils.setAlphaLimit(0f)
                    BloomUtil.drawAndBloom {
                        FontLoaders.SF16.drawStringWithShadow(
                            clientName.get(), 9.0,
                            9.0, Color(0, 0, 0, 0).rgb
                        )
                    }
                }
                GlStateManager.resetColor()


                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "|",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + 11,
                    9, Color(100, 100, 100).rgb
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "$username",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + 11,
                    9,
                    -1
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "|",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + x2 + 11,
                    9,
                    Color(100, 100, 100).rgb
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "$servername",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + x2 + x3 + 11,
                    9,
                    -1
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "|",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + x2 + x3 + x4 + 15,
                    9,
                    Color(100, 100, 100).rgb
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "$times",
                    Fonts.tenacitybold35.getStringWidth(clientName.get()) + x1 + x2 + x3 + x4 + x5 + 11,
                    9,
                    -1
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "|",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + x2 + x3 + x4 + x5 + x6 + 11,
                    9,
                    Color(100, 100, 100).rgb
                )

                net.ccbluex.liquidbounce.ui.client.fonts.impl.Fonts.SF.SF_16.SF_16.drawString(
                    "$fps",
                    FontLoaders.SF16.getStringWidth(clientName.get()) + x1 + x2 + x3 + x4 + x5 + x6 + x7 + 11,
                    9,
                    -1
                )
                GlStateManager.resetColor()

            }
        }
        if (infoValue.get()) {
            drawInfo(clientColors)
        }
    }

    private fun mixColors(color1: Color, color2: Color): Color {
        return if (sColors.get()) {
            ColorUtil.interpolateColorsBackAndForth(
                15,
                1,
                color1,
                color2,
                hueInterpolation.get()
            )
        } else {
            ColorUtil.interpolateColorC(color1, color2, 0F)
        }
    }

    fun getClientColor(): Color {
        return Color(AColorPalette.r.get(), AColorPalette.g.get(), AColorPalette.b.get())
    }

    fun getAlternateClientColor(): Color {
        return Color(AColorPalette.r2.get(), AColorPalette.g2.get(), AColorPalette.b2.get())
    }

    val clientColors: Array<Color>
        get() {
            val firstColor: Color
            val secondColor: Color
            when (colorMode.get().toLowerCase()) {
                "light rainbow" -> {
                    firstColor = ColorUtil.rainbow(15, 1, .6f, 1f, 1f)
                    secondColor = ColorUtil.rainbow(15, 40, .6f, 1f, 1f)
                }

                "rainbow" -> {
                    firstColor = ColorUtil.rainbow(15, 1, 1f, 1f, 1f)
                    secondColor = ColorUtil.rainbow(15, 40, 1f, 1f, 1f)
                }

                "gident" -> {
                    firstColor =
                        mixColors(getClientColor(), getAlternateClientColor())
                    secondColor =
                        mixColors(getAlternateClientColor(), getClientColor())
                }

                else -> {
                    firstColor = Color(-1)
                    secondColor = Color(-1)
                }
            }
            return arrayOf(firstColor, secondColor)
        }

    fun getFadeProgress() = 0f
    fun getColor(color: Color) = ColorUtils.reAlpha(color, color.alpha / 255F * (1F - getFadeProgress()))
    fun getColor(color: Int) = getColor(Color(color))
    private fun getColorAtIndex(i: Int): Int {
        return getColor(
            when (AColorPalette.colorModeValue.get()) {
                "Rainbow" -> RenderUtils.getRainbowOpaque(
                    AColorPalette.waveSecondValue.get(),
                    AColorPalette.saturationValue.get(),
                    AColorPalette.brightnessValue.get(),
                    i * AColorPalette.gradientDistanceValue.get()
                )

                "Sky" -> RenderUtils.SkyRainbow(
                    i * AColorPalette.gradientDistanceValue.get(),
                    AColorPalette.saturationValue.get(),
                    AColorPalette.brightnessValue.get()
                )

                "Slowly" -> ColorUtils.LiquidSlowly(
                    System.nanoTime(),
                    i * AColorPalette.gradientDistanceValue.get(),
                    AColorPalette.saturationValue.get(),
                    AColorPalette.brightnessValue.get()
                ).rgb

                "Fade" -> ColorUtils.fade(
                    Color(AColorPalette.r.get(), AColorPalette.g.get(), AColorPalette.b.get()),
                    i * AColorPalette.gradientDistanceValue.get(),
                    100
                ).rgb

                "Gident" -> RenderUtils.getGradientOffset(
                    Color(AColorPalette.r.get(), AColorPalette.g.get(), AColorPalette.b.get()), Color(
                        AColorPalette.r2.get(), AColorPalette.g2.get(),
                        AColorPalette.b2.get(), 1
                    ), (Math.abs(
                        System.currentTimeMillis() /
                                AColorPalette.gradientSpeed.get()
                                    .toDouble() + i * AColorPalette.gradientDistanceValue.get()
                    ) / 10)
                ).rgb

                else -> -1
            }
        ).rgb
    }


    override val tag: String
        get() = logoValue.get()
}
