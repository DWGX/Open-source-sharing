/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(
    name = "Ghost",
    description = "Allows you to walk around and interact with your environment after dying.",
    category = ModuleCategory.HYT
)
class Ghost : Module() {

    private var isGhost = false

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return

        if (classProvider.isGuiGameOver(mc.currentScreen)) {
            mc.displayGuiScreen(null)
            thePlayer.isDead = false
            thePlayer.health = 20F
            thePlayer.setPositionAndUpdate(thePlayer.posX, thePlayer.posY, thePlayer.posZ)
            isGhost = true

            ClientUtils.displayChatMessage("§c[Emperor]BypassDead")
        }
    }

    override fun onDisable() {
        val thePlayer = mc.thePlayer

        if (isGhost && thePlayer != null) {
            thePlayer.respawnPlayer()
            isGhost = false
        }
    }

}