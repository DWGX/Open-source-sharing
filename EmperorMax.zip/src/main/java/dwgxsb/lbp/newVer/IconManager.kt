package dwgxsb.lbp.newVer

import net.ccbluex.liquidbounce.LiquidBounce

object IconManager {
    @JvmField
    val removeIcon = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/error.png")
    val add = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/import.png")
    val back = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/back.png")
    val docs = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/docs.png")
    val download = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/download.png")
    val folder = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/folder.png")
    val online = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/online.png")
    val reload = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/reload.png")
    val search = LiquidBounce.wrapper.classProvider.createResourceLocation("dwgx/newgui/clickgui/search.png")
}