package dwgxsb;


import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class TCP {
    public static void ilililililil() throws IOException {
        String username = JOptionPane.showInputDialog(null, "用户名:                                                    USERNAME", "Login-Verify", JOptionPane.PLAIN_MESSAGE);
        JFrame frame = new JFrame();
        frame.setAlwaysOnTop(true); // 设置窗口始终在顶层
        String password = JOptionPane.showInputDialog(null, "密码:                                                       PASSWORD ", "Login-Verify", JOptionPane.PLAIN_MESSAGE);
        try {
            // 设置连接使用代理
            URL url = new URL("https://gitcode.net/m0_74037382/emperor/-/raw/master/Guilogin");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            // 解析服务器响应
            if (net.ccbluex.liquidbounce.utils.misc.HttpUtils.get("https://gitcode.net/m0_74037382/emperor/-/raw/master/Guilogin")
                    .contains("Name:[" + username + "]" + "Password:[" + password + "]" + "Token[" + LiquidBounce.INSTANCE.gettoken().trim() + "]" + "Hwid[" + LiquidBounce.INSTANCE.gethwid().trim() + "]")) {
                displayTray("EmperorMAX", "欢迎尊敬的User", TrayIcon.MessageType.INFO);
            } else {
                JOptionPane.showMessageDialog(null, "黑客止步！HakcerStop\nUsername与Token以自动复制到剪贴板\n", "HackerStop", JOptionPane.ERROR_MESSAGE);
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection("Name:[" + username + "]" + "Password:[" + password + "]" + "Token[" + LiquidBounce.INSTANCE.gettoken().trim() + "]" + "Hwid[" + LiquidBounce.INSTANCE.gethwid().trim() + "]"), null);
                MinecraftInstance.mc.shutdown();
                MinecraftInstance.mc2.shutdown();
                System.exit(0);
            }
        } catch (IOException e) {
            e.printStackTrace(); // 打印异常的堆栈跟踪信息
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    }

    private static void displayTray(String Title, String Text, TrayIcon.MessageType type) throws AWTException {
        SystemTray tray = SystemTray.getSystemTray();
        java.awt.Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("System tray icon demo");
        tray.add(trayIcon);
        trayIcon.displayMessage(Title, Text, type);
    }

}