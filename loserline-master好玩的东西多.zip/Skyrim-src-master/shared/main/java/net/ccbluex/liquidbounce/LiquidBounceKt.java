package net.ccbluex.liquidbounce;

import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.utils.HWIDUtils;
import oh.yalan.NativeClass;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
@NativeClass
public final class LiquidBounceKt {
   public static void verify() throws IOException, NoSuchAlgorithmException {
      String username = JOptionPane.showInputDialog("Input Username");
      //String username = JOptionPane.showInputDialog("Input Username");


      String hwid = HWIDUtils.getHWID();
      URL url = new URL("https://gitee.com/yzITI_admin/shenbihwid3/raw/master/hwid.txt");
      URLConnection var10000 = url.openConnection();
      HttpURLConnection connection = (HttpURLConnection) var10000;
      connection.setDoInput(true);
      InputStream var6 = connection.getInputStream();
      Intrinsics.checkNotNullExpressionValue(var6, "connection.inputStream");
      Charset var7 = StandardCharsets.UTF_8;
      Reader var8 = (Reader) (new InputStreamReader(var6, var7));
      short var9 = 8192;
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type java.net.HttpURLConnection");
      } else {
         BufferedReader reader = var8 instanceof BufferedReader ? (BufferedReader) var8 : new BufferedReader(var8, var9);
         boolean pass = false;
         Iterator var10 = TextStreamsKt.readLines((Reader) reader).iterator();
         if(!pass){
            String c = (String) var10.next();

            if (get("https://gitee.com/yzITI_admin/shenbihwid3/raw/master/hwid.txt").contains (username + ':' + hwid)) {
               LiquidBounce.INSTANCE.setUsername(username);
               if(username == "") System.exit(0);
               pass = true;

            } else {
               JOptionPane.showInputDialog("Auth Failed Copy UR HWID TO ADMIN.", (Object) hwid);
               System.exit(0);
            }
         }
         connection.disconnect();
      }

   }
   public static String get(String url) throws IOException {
      HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();

      con.setRequestMethod("GET");
      con.setRequestProperty("User-Agent", "Mozilla/5.0");

      BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
      String inputLine;
      StringBuilder response = new StringBuilder();

      while((inputLine = in.readLine())!= null) {
         response.append(inputLine);
         response.append("\n");
      }

      in.close();

      return response.toString();
   }
   @NotNull
   public static final String buildHWID() throws NoSuchAlgorithmException, UnsupportedEncodingException {
      System.out.println(HWIDUtils.getHWID());
      return HWIDUtils.getHWID();
   }
   @NotNull
   public static final String digest(@NotNull String s) throws NoSuchAlgorithmException {
      Intrinsics.checkNotNullParameter(s, "s");
      StringBuilder builder = new StringBuilder();
      MessageDigest digest = MessageDigest.getInstance("MD5");
      Charset var5 = StandardCharsets.UTF_8;
      Intrinsics.checkNotNullExpressionValue(var5, "UTF_8");
      byte[] var6 = s.getBytes(var5);
      Intrinsics.checkNotNullExpressionValue(var6, "this as java.lang.String).getBytes(charset)");
      byte[] b = digest.digest(var6);
      Intrinsics.checkNotNullExpressionValue(b, "b");
      byte[] var4 = b;
      int var9 = 0;
      int var10 = b.length;

      while(var9 < var10) {
         byte var7 = var4[var9];
         ++var9;
         builder.append(Integer.toHexString(var7 & 255));
      }

      String var8 = builder.toString();
      Intrinsics.checkNotNullExpressionValue(var8, "builder.toString()");
      return var8;
   }
}
