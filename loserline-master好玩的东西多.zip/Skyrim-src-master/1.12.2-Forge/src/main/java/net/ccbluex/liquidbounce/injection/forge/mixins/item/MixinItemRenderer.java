/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.injection.forge.mixins.item;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.features.module.modules.render.Animations;
import net.ccbluex.liquidbounce.features.module.modules.render.AntiBlind;
import net.ccbluex.liquidbounce.features.module.modules.render.OldHitting;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static me.aquavit.liquidsense.utils.Debug.*;

@Mixin(ItemRenderer.class)
@SideOnly(Side.CLIENT)
public abstract class MixinItemRenderer {

    @Shadow
    @Final
    private Minecraft mc;
    @Shadow
    private ItemStack itemStackOffHand;

    @Shadow
    private ItemStack itemStackMainHand;

    @Shadow
    protected abstract void renderMapFirstPerson(float p_187463_1_, float p_187463_2_, float p_187463_3_);

    @Shadow
    protected abstract void transformFirstPerson(EnumHandSide hand, float swingProgress);


    @Shadow
    protected abstract void transformEatFirstPerson(float p_187454_1_, EnumHandSide hand, ItemStack stack);

    @Shadow
    protected abstract void renderArmFirstPerson(float p_187456_1_, float p_187456_2_, EnumHandSide p_187456_3_);

    @Shadow
    protected abstract void renderMapFirstPersonSide(float p_187465_1_, EnumHandSide hand, float p_187465_3_, ItemStack stack);

    @Shadow
    protected abstract void transformSideFirstPerson(EnumHandSide hand, float p_187459_2_);

    @Shadow
    public abstract void renderItemSide(EntityLivingBase entitylivingbaseIn, ItemStack heldStack, ItemCameraTransforms.TransformType transform, boolean leftHanded);

    /**
     * @author Skidder
     * @reason L
     */
    @Overwrite
    public void renderItemInFirstPerson(AbstractClientPlayer player, float p_187457_2_, float p_187457_3_, EnumHand hand, float p_187457_5_, ItemStack stack, float p_187457_7_) {
        boolean flag = hand == EnumHand.MAIN_HAND;
        EnumHandSide enumhandside = flag ? player.getPrimaryHand() : player.getPrimaryHand().opposite();
        GlStateManager.pushMatrix();
        OldHitting ot = (OldHitting)LiquidBounce.moduleManager.getModule(OldHitting.class);
        KillAura aura = (KillAura)LiquidBounce.moduleManager.getModule(KillAura.class);
        if (ot.getState()) {
            doItemRenderGLTranslate();
            doItemRenderGLScale();
        }


        if (stack.isEmpty()) {
            if (flag && !player.isInvisible()) {
                this.renderArmFirstPerson(p_187457_7_, p_187457_5_, enumhandside);
            }
        } else if (stack.getItem() == Items.FILLED_MAP) {
            if (flag && this.itemStackOffHand.isEmpty()) {
                this.renderMapFirstPerson(p_187457_3_, p_187457_7_, p_187457_5_);
            } else {
                this.renderMapFirstPersonSide(p_187457_7_, enumhandside, p_187457_5_, stack);
            }
        } else {
            boolean flag1 = enumhandside == EnumHandSide.RIGHT;

            if (player.isHandActive() && player.getItemInUseCount() > 0 && player.getActiveHand() == hand) {
                int j = flag1 ? 1 : -1;

                switch (stack.getItemUseAction()) {
                    case NONE:

                        double f = 0;
                        genCustom((float) f, 0.83f);
                        //func_178103_d2();
                        f = Math.sin(p_187457_5_ * p_187457_5_ * Math.PI);
                        double f1 = Math.sin(Math.sqrt(p_187457_5_) * Math.PI);
                        // transformFirstPersonItem(1F,1F);
                        this.transformSideFirstPerson(enumhandside, p_187457_2_);
                  //      this.doItemRenderGLTranslate();
                        break;
                    case EAT:
                    case DRINK:
                        this.transformEatFirstPerson(p_187457_2_, enumhandside, stack);
                        this.transformSideFirstPerson(enumhandside, p_187457_7_);
                        break;

                    case BLOCK:
                        this.transformSideFirstPerson(enumhandside, p_187457_7_);
                        break;
                    case BOW:
                        this.transformSideFirstPerson(enumhandside, p_187457_7_);
                        GlStateManager.translate((float) j * -0.2785682F, 0.18344387F, 0.15731531F);
                        GlStateManager.rotate(-13.935F, 1.0F, 0.0F, 0.0F);
                        GlStateManager.rotate((float) j * 35.3F, 0.0F, 1.0F, 0.0F);
                        GlStateManager.rotate((float) j * -9.785F, 0.0F, 0.0F, 1.0F);
                        float f5 = (float) stack.getMaxItemUseDuration() - ((float) this.mc.player.getItemInUseCount() - p_187457_2_ + 1.0F);
                        float f6 = f5 / 20.0F;
                        f6 = (f6 * f6 + f6 * 2.0F) / 3.0F;

                        if (f6 > 1.0F) {
                            f6 = 1.0F;
                        }

                        if (f6 > 0.1F) {
                            float f7 = MathHelper.sin((f5 - 0.1F) * 1.3F);
                            float f3 = f6 - 0.1F;
                            float f4 = f7 * f3;
                            GlStateManager.translate(f4 * 0.0F, f4 * 0.004F, f4 * 0.0F);
                        }

                        GlStateManager.translate(f6 * 0.0F, f6 * 0.0F, f6 * 0.04F);
                        GlStateManager.scale(1.0F, 1.0F, 1.0F + f6 * 0.2F);
                        GlStateManager.rotate((float) j * 45.0F, 0.0F, -1.0F, 0.0F);
                }
            } else {
                if(ot.getState()){
                    if ((aura.getBlockingStatus() || itemStackOffHand.getItem() instanceof ItemShield) && (player.getActiveItemStack() == itemStackOffHand || thePlayerisBlocking) && itemStackMainHand.getItem() instanceof ItemSword) {
                        final String z = ot.getModeValue().get();
                        switch(z){
                            case "Vanilla": {
                                Vanilla(enumhandside, p_187457_7_, p_187457_5_);
                                break;

                            }
                            case "slide": {
                                slide2(enumhandside, p_187457_7_, p_187457_5_);
                                break;
                            }
                            case "Remix":{
                                Remix(enumhandside, p_187457_7_, p_187457_5_);
                            }
                            case "1.8": {
                                transformSideFirstPersonBlock(enumhandside, p_187457_7_, p_187457_5_);
                                break;
                            }
                            case "Push": {
                                Push(enumhandside, p_187457_7_, p_187457_5_);
                                break;
                            }
                            case "WindMill": {
                                double f = Math.sin(p_187457_7_ * p_187457_7_ * Math.PI);
                                WindMill(enumhandside, 0, 0);
                                GlStateManager.rotate((float) (Math.sqrt(f) * 10F * 40.0F), 1F, -0.0F, 2F);
                                break;
                            }
                        }


                    } else {
                        if(!MinecraftInstance.mc.getThePlayer().isBlocking()) {
                            float f = -0.4F * MathHelper.sin(MathHelper.sqrt(p_187457_5_) * (float) Math.PI);
                            float f1 = 0.2F * MathHelper.sin(MathHelper.sqrt(p_187457_5_) * ((float) Math.PI * 2F));
                            float f2 = -0.2F * MathHelper.sin(p_187457_5_ * (float) Math.PI);
                            int i = flag1 ? 1 : -1;
                            GlStateManager.translate((float) i * f, f1, f2);
                            //GlStateManager.translate(Animations.itemPosX.get(), Animations.itemPosY.get(), Animations.itemPosZ.get());

                            doItemRenderGLTranslate();
                            doItemRenderGLScale();
                            this.transformSideFirstPerson(enumhandside, p_187457_7_);
                            this.transformFirstPerson(enumhandside, p_187457_5_);

                        }else{

                            float f = -0.4F * MathHelper.sin(MathHelper.sqrt(p_187457_5_) * (float) Math.PI);
                            float f1 = 0.2F * MathHelper.sin(MathHelper.sqrt(p_187457_5_) * ((float) Math.PI * 2F));
                            float f2 = -0.2F * MathHelper.sin(p_187457_5_ * (float) Math.PI);
                            int i = flag1 ? 1 : -1;
                            GlStateManager.translate((float) i * f, f1, f2);
                            //GlStateManager.translate(Animations.itemPosX.get(), Animations.itemPosY.get(), Animations.itemPosZ.get());

                            //doItemRenderGLTranslate();
                            //doItemRenderGLScale();
                            this.transformSideFirstPerson(enumhandside, p_187457_7_);
                            this.transformFirstPerson(enumhandside, p_187457_5_);
                        }

                    }
                } else {
                  /*  this.transformSideFirstPerson(enumhandside, p_187457_7_);
                    this.transformFirstPerson(enumhandside, p_187457_5_);*/
         //           this.transformFirstPersonItem(0F, 0F);
                    GlStateManager.translate(-0.5F, 0.2F, 0.0F);
                }

            }
            if(ot.getState()){
                if (stack.getItem() instanceof ItemShield && itemStackMainHand.getItem() instanceof ItemSword) {
                    GlStateManager.popMatrix();
                    return;
                }
                this.renderItemSide(player, stack, flag1 ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !flag1);
            } else {
                this.renderItemSide(player, stack, flag1 ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !flag1);
            }

        }

        GlStateManager.popMatrix();
    }


    /**
     * @author CCBlueX
     */


    @Inject(method = "renderFireInFirstPerson", at = @At("HEAD"), cancellable = true)
    private void renderFireInFirstPerson(final CallbackInfo callbackInfo) {
        final AntiBlind antiBlind = (AntiBlind) LiquidBounce.moduleManager.getModule(AntiBlind.class);

        if (antiBlind.getState() && antiBlind.getFireEffect().get()) callbackInfo.cancel();
    }


 /*   private void transformFirstPersonItem(float equipProgress, float swingProgress) {
        GlStateManager.translate(0.0F, equipProgress * -0.6F, 0.0F);
        GlStateManager.rotate(45.0F, 0.0F, 1.0F, 0.0F);
        float f = MathHelper.sin(swingProgress * swingProgress * 3.1415927F);
        float f1 = MathHelper.sin(MathHelper.sqrt(swingProgress) * 3.1415927F);
        GlStateManager.rotate(f * -20.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(f1 * -20.0F, 0.0F, 0.0F, 1.0F);
        GlStateManager.rotate(f1 * -80.0F, 1.0F, 0.0F, 0.0F);
        Animations ani = (Animations) LiquidBounce.moduleManager.getModule(Animations.class);
        if (ani.getState()) {
            doItemRenderGLTranslate();
            doItemRenderGLScale();
        }
    } */

    private void doItemRenderGLTranslate(){
        GlStateManager.translate(Animations.itemPosX.get(), Animations.itemPosY.get(), Animations.itemPosZ.get());
    }

    private void doItemRenderGLScale(){
        GlStateManager.scale(Animations.Scale.get(), Animations.Scale.get(),  Animations.Scale.get());
    }
}