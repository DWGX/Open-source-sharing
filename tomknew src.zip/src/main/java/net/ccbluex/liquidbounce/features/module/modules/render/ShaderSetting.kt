package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import java.awt.Color

@ModuleInfo(name = "Shader", description = "open blur/bloom and ShaderSetting", category = ModuleCategory.RENDER, array = false)
class ShaderSetting : Module() {

    val blur = BoolValue("Blur", false)
     val  outline = BoolValue("Outline", true)

    val colorRedValue = IntegerValue("PictureColorR", 0, 0, 255)
    val colorGreenValue = IntegerValue("PictureColorG", 255, 0, 255)
    val colorBlueValue = IntegerValue("PictureColorB", 255, 0, 255)
    val coloralpha = IntegerValue("PictureColoralpha", 255, 0, 255)

    val colorRed2Value = IntegerValue("PictureColor2R", 0, 0, 255)
    val colorGreen2Value = IntegerValue("PictureColor2G", 0, 0, 255)
    val colorBlue2Value = IntegerValue("PictureColor2B", 255, 0, 255)
    val coloralpha2 = IntegerValue("PictureColor2alpha", 255, 0, 255)
    val arraylistshader = BoolValue("arraylisShader", false)
    val arraylistblur = BoolValue("arraylistBlur", false)
    val arraylistgloom = BoolValue("arraylistShadow", true)
    val arraylistshaderstr = IntegerValue("arraylistShaderStr", 3, 1, 5)
    val arraylistshaderoff = IntegerValue("arraylistShaderOff", 1, 1, 5)
    var firstcolor = Color(colorRedValue.get(),colorGreenValue.get(),colorBlueValue.get(),coloralpha.get())
    var secondcolor = Color(colorRedValue.get(),colorGreenValue.get(),colorBlueValue.get(),coloralpha.get())
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
         firstcolor = Color(colorRedValue.get(),colorGreenValue.get(),colorBlueValue.get(),coloralpha.get())
         secondcolor = Color(colorRed2Value.get(),colorGreen2Value.get(),colorBlue2Value.get(),coloralpha2.get())
    }



}