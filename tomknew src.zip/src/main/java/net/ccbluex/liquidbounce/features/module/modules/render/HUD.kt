/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.color.CustomUI
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.AnimationUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils.hud
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil
import net.ccbluex.liquidbounce.utils.render.tenacity.GradientUtil
import net.ccbluex.liquidbounce.value.*
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.Display
import org.lwjgl.opengl.GL11
import tomk.utils.BlurBuffer
import tomk.utils.ShadowUtils
import java.awt.Color
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow

@ModuleInfo(name = "HUD", description = "Toggles visibility of the HUD.", category = ModuleCategory.RENDER, array = false)
class HUD : Module() {
    val animHotbarValue = BoolValue("AnimatedHotbar", true)
    private val toggleMessageValue = BoolValue("DisplayToggleMessage", true)
    private val toggleSoundValue = ListValue("ToggleSound", arrayOf("None", "Default", "Custom"), "Custom")
    val domainValue = TextValue("Scoreboard-Domain", "TomkClient@2023")
    private val infoValue = BoolValue("Info", false)
    val fontChatValue = BoolValue("FontChat", false)
    val chatRect = BoolValue("ChatRect", false)
    val chatAnimValue = BoolValue("ChatAnimation", true)
    @JvmField
    val hotbar = BoolValue("Hotbar", false)
    val hueInterpolation = BoolValue("HueInterpolate", false)
    val inventoryParticle = BoolValue("InventoryParticle", false)
    val blurValue = BoolValue("Blur", false)
    val BlurStrength = FloatValue("BlurStrength", 15F, 0f, 30F)//这是模糊°
    val Radius = IntegerValue("BlurRadius", 10 , 1 , 50 )
    val ChineseScore = BoolValue("ChineseScore", true)
    var logomode = ListValue("LogoMode", arrayOf("Tomk","Neon","CowB","Skidded","LiquidBounce","TomkMax","None"), "TomkMax")
    //Logo
    val clientname = TextValue("clientname", "Tomk Max")
    val changeValue = BoolValue("ChangeLogoName", false)
    val modeValue = ListValue("LogoMode", arrayOf("None","Neverlose","TomkMax","Distance","Novo"), "None")
    val logoradius = FloatValue("Neverlose-Radius", 3f, 0f, 10f)
    val novoradius = FloatValue("Novo-Radius", 5f, 0f, 10f)
    val nb = IntegerValue("Novo-Alpha", 150, 0, 255)
    val ss = FloatValue("Novo-ShadowStrength", 5f, 0f, 30f)
    val bs = FloatValue("Novo-BlurStrength", 5f, 0f, 30f)
    val nfont = ListValue("Novo-TitleFont", arrayOf("Title","TenacityBold","Neverlose900"),"Title")
    companion object {
        val clolormode = ListValue(
                "ColorMode", arrayOf(
                "Rainbow",
                "Light Rainbow",
                "Static",
                "Gident",
                "Double Color",
                "Default"
        ), "Light Rainbow"
        )
    }
    private var easingHealth = 0f
    private val decimalFormat:DecimalFormat = DecimalFormat()
    private var easingarmor: Float = 0F
    private var easingxp: Float = 0F
    private var easingfood: Float = 0F
    private val dateFormat = SimpleDateFormat("HH:mm:ss")
    private fun getClientColor(hud: HUD): Color {
        return Color(CustomUI.r.get(), CustomUI.g.get(), CustomUI.b.get())
    }
    private fun getAlternateClientColor(hud: HUD): Color {
        return Color(CustomUI.r2.get(), CustomUI.g2.get(), CustomUI.b2.get())
    }
    private fun mixColors(color1: Color, color2: Color): Color {
        return ColorUtil.interpolateColorsBackAndForth(
            15,
            1,
            color1,
            color2,
            hueInterpolation.get()
        )
    }
    val clientColors: Array<Color>
        get() {
            val firstColor: Color
            val secondColor: Color
            firstColor =
                mixColors(getClientColor(hud), getAlternateClientColor(hud))
            secondColor =
                mixColors(getAlternateClientColor(hud), getClientColor(hud))
            return arrayOf(firstColor, secondColor)}

    @EventTarget
    fun onTick(event: TickEvent) {
        LiquidBounce.moduleManager.shouldNotify = toggleMessageValue.get()
        LiquidBounce.moduleManager.toggleSoundMode = toggleSoundValue.values.indexOf(toggleSoundValue.get())
    }
    val sr = ScaledResolution(mc2)
    val left: Int = sr.getScaledWidth() / 2 + 91
    val top: Int = sr.getScaledHeight() - 100
    val x = 380
    private var hotBarX = 0F
    fun getAnimPos(pos: Float): Float {
        if (state && animHotbarValue.get()) hotBarX = AnimationUtils.animate(pos, hotBarX, 0.02F * RenderUtils.deltaTime.toFloat())
        else hotBarX = pos

        return hotBarX
    }
    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        if (classProvider.isGuiHudDesigner(mc.currentScreen)) return
        LiquidBounce.hud.render(false)
        var df = SimpleDateFormat("HH:mm")
        val sr = ScaledResolution(mc2)
        val left = sr.scaledWidth / 2 + 91
        val top= sr.scaledHeight - 50
        val x = left - 1 * 8 - 180
        val sigmaY = 4
        val sigmaX = 8
        val scaledResolution = ScaledResolution(mc2)
        if (infoValue.get()) {
            val text = String.format(
                    "Verson:" + LiquidBounce.CLIENT_VERSION
            )
            val bps = Math.hypot(
                    mc.thePlayer!!.posX - mc.thePlayer!!.prevPosX,
                    mc.thePlayer!!.posZ - mc.thePlayer!!.prevPosZ
            ) * mc.timer.timerSpeed * 20
            val XYZ = String.format(
                    "XYZ: " + mc2.player.posX.toInt() + ", " + mc2.player.posY.toInt() + "," + mc2.player.posZ.toInt()
            )
            val FPS = String.format(

                    "FPS: " + Minecraft.getDebugFPS()

            )
            val BPS = String.format(
                    "BPS: " + Math.round(bps * 100.0) / 100.0
            )
            Fonts.productSans35.drawString(
                    text,
                    (classProvider.createScaledResolution(mc).scaledWidth - Fonts.productSans35.getStringWidth(text) - 2).toFloat(),
                    ((classProvider.createScaledResolution(mc).scaledHeight - Fonts.productSans35.fontHeight - 1).toDouble()
                            .toFloat()),
                    Color(210, 210, 210).rgb,
                    true
            )
            Fonts.productSans35.drawString(
                    XYZ,
                    2f,
                    (scaledResolution.scaledHeight - 10).toFloat(),
                    Color(210, 210, 210).rgb,
                    true
            )
            Fonts.productSans35.drawString(
                    BPS,
                    2f,
                    (scaledResolution.scaledHeight - 10- Fonts.productSans35.fontHeight).toFloat(),
                    Color(210, 210, 210).rgb,
                    true
            )
            Fonts.productSans35.drawString(
                    FPS,
                    2f,
                    (scaledResolution.scaledHeight - 10- Fonts.productSans35.fontHeight*2).toFloat(),
                    Color(210, 210, 210).rgb,
                    true
            )
        }
        if (hotbar.get() && mc.thePlayer != null && mc.theWorld != null ) {
            var color2 = Color(212 ,48 ,48).rgb
            if (easingHealth <= 0f ){
                easingHealth  = 0F
            }
            if (easingHealth >= mc.thePlayer!!.maxHealth ){
                easingHealth  = mc.thePlayer!!.maxHealth
            }
            if (easingarmor <= 0){
                easingarmor = 0F
            }
            if (easingarmor >= 20f){
                easingarmor = 20F
            }
            if (easingfood <= 0){
                easingfood = 0F
            }
            if (easingfood >= 20f){
                easingfood = 20F
            }
            if (mc.thePlayer!!.isPotionActive(classProvider.getPotionEnum(PotionType.REGENERATION))){ color2 = Color(200, 90, 90).rgb }
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()-8, 100F, 5f, 1f, Color(126,11,11))
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()-8, (easingHealth / mc.thePlayer!!.maxHealth) * 100F, 5f, 1f, Color(color2))
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()+10f, 210f, 5f, 1f, Color(37,94,37))
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()+10f, (easingxp / 20F) * 40, 5f, 1f,Color(65, 205, 125))
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()-18, 100f, 5f, 1f, Color(35,105,136))
            RoundedUtil.drawRound(x.toFloat(), top.toFloat()-18, (easingarmor / 20F) * 100F, 5f, 1f, Color(73,173,203))
            RoundedUtil.drawRound(x.toFloat() + 110F, top.toFloat()-8, 100f, 5f, 1f, Color(100,76,37))
            RoundedUtil.drawRound(x.toFloat() + 110F, top.toFloat()-8, (easingfood / 20F) * 100F, 5f, 1f, Color(255 ,140 ,25))
            Fonts.posterama30.drawString("Armo/" +decimalFormat.format((easingarmor / 20f) * 100f) + "%", x.toFloat() +2, ((top+3  - Fonts.posterama30.fontHeight / 2).toFloat()) - 3f - 15f, Color(255,255,255).rgb)
            var reasingHealth = Math.round(easingHealth / mc.thePlayer!!.maxHealth * 100f).toFloat()
            var s = StringBuilder().append(DecimalFormat().format(java.lang.Float.valueOf(reasingHealth))).append("%").toString()
            Fonts.posterama30.drawString("HP/" +s, x.toFloat() +2, ((top - 5 - Fonts.posterama30.fontHeight / 2).toFloat()), Color(255,255,255).rgb)
            Fonts.posterama30.drawString("Level/" + mc2.player.experienceLevel.toString(), x.toFloat()+95, ((top.toFloat()+6f- Fonts.posterama30.fontHeight / 2)), Color(255,255,255).rgb)
            Fonts.posterama30.drawString("Starvation/" + decimalFormat.format((easingfood / 20F) * 100F) + "%", x.toFloat()+110F +2, ((top - 5 - Fonts.posterama30.fontHeight / 2).toFloat()), Color(255,255,255).rgb)
            easingfood += (mc2.player.foodStats.foodLevel - easingfood) / 2.0F.pow(10.0F - 5F) * RenderUtils.deltaTime
            easingxp += ((mc2.player.experience * 100F) - easingxp) / 2.0F.pow(10.0F - 5F) * RenderUtils.deltaTime
            easingHealth += ((mc.thePlayer!!.health - easingHealth) / 2.0F.pow(10.0F - 5F)) * RenderUtils.deltaTime
            easingarmor += ((mc2.player.totalArmorValue - easingarmor) / 2.0F.pow(10.0F - 5F)) * RenderUtils.deltaTime
        }
        if ("Tomk" == logomode.get()) {
            Display.setTitle("Minecraft.net 1.12.2");
            Fonts.productSans52.drawString("§bT§romk Max"+" ("+ df.format(Date())+")", 3F, 3f, Color(0xFFFFFF).rgb)
            Fonts.productSans35.drawString("§bU§rserName: "+LiquidBounce.UserName, 5F, 18f, Color(0xFFFFFF).rgb)
        }
        if ("TomkMax" == logomode.get()) {
            Display.setTitle("Minecraft.net 1.12.2");
        }
        if ("Neon" == logomode.get()) {
            Fonts.productSans52.drawString("§bN§reon"+" ("+ df.format(Date())+")", 3F, 3f, Color(0xFFFFFF).rgb)
            Fonts.productSans35.drawString("§bU§rserName: "+LiquidBounce.UserName, 5F, 18f, Color(0xFFFFFF).rgb)
        }
        if ("CowB" == logomode.get()) {
            Fonts.productSans52.drawString("§bC§rowB Client"+" ("+ df.format(Date())+")", 3F, 3f, Color(0xFFFFFF).rgb)
            Fonts.productSans35.drawString("§bU§rserName: "+LiquidBounce.UserName, 5F, 18f, Color(0xFFFFFF).rgb)
        }
        if ("Skidded" == logomode.get()) {
            Fonts.productSans52.drawString("§bS§rkiderrSense"+" ("+ df.format(Date())+")", 3F, 3f, Color(0xFFFFFF).rgb)
            Fonts.productSans35.drawString("§bU§rserName: "+LiquidBounce.UserName, 5F, 18f, Color(0xFFFFFF).rgb)
        }
        if ("LiquidBounce" == logomode.get()) {
            Fonts.productSans52.drawString("§bL§riquidBounce"+" ("+ df.format(Date())+")", 3F, 3f, Color(0xFFFFFF).rgb)
            Fonts.productSans35.drawString("§bU§rserName: "+LiquidBounce.UserName, 5F, 18f, Color(0xFFFFFF).rgb)
        }
        LiquidBounce.hud.render(false)
        when (modeValue.get()) {
            "Novo" -> {
                val username = LiquidBounce.USERNAME
                val servername = if (mc2.isSingleplayer) "Singleplayer" else mc2.currentServerData?.serverIP
                val fps = Minecraft.getDebugFPS().toString() + " FPS"
                ShadowUtils.shadow(ss.get(),{
                    GL11.glPushMatrix()
                    if(nfont.get().equals("TenacityBold")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.tenacitybold40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 19f),22f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    else if(nfont.get().equals("Title")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.title40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 19f),22f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    else if(nfont.get().equals("Neverlose900")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.never900_40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 19f),22f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    GL11.glPopMatrix()

                },{
                    GL11.glPushMatrix()
                    GlStateManager.enableBlend()
                    GlStateManager.disableTexture2D()
                    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0)
                    if(nfont.get().equals("TenacityBold")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.tenacitybold40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),23f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    else if(nfont.get().equals("Title")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.title40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),22f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    else if(nfont.get().equals("Neverlose900")) {
                        RenderUtils.drawRoundedRect(7f,6f,Fonts.never900_40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),22f,novoradius.get(),Color(0,0,0).rgb)
                    }
                    GlStateManager.enableTexture2D()
                    GlStateManager.disableBlend()
                    GL11.glPopMatrix()
                })

                if (nfont.get().equals("TenacityBold")){
                    RenderUtils.drawRoundedRect(7f,6f,Fonts.tenacitybold40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),22f,novoradius.get(),Color(32,32,32,nb.get()).rgb)
                }
                if (nfont.get().equals("Title")){
                    RenderUtils.drawRoundedRect(7f,6f,Fonts.title40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),22f,novoradius.get(),Color(32,32,32,nb.get()).rgb)
                }
                if (nfont.get().equals("Neverlose900")){
                    RenderUtils.drawRoundedRect(7f,6f,Fonts.never900_40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 20f),22f,novoradius.get(),Color(32,32,32,nb.get()).rgb)
                }
                if (nfont.get().equals("TenacityBold")){
                    BlurBuffer.CustomBlurRoundArea(7f,6f,Fonts.tenacitybold40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 13f),17f,novoradius.get(),bs.get())
                }
                if (nfont.get().equals("Title")){
                    BlurBuffer.CustomBlurRoundArea(7f,6f,Fonts.title40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 13f),17f,novoradius.get(),bs.get())
                }
                if (nfont.get().equals("Neverlose900")){
                    BlurBuffer.CustomBlurRoundArea(7f,6f,Fonts.never900_40.getStringWidth("Tomk Max").toFloat() + (Fonts.productSans35.getStringWidth("| Reborn | $username | $fps | $servername") + 13f),17f,novoradius.get(),bs.get())
                }
                if(nfont.get().equals("TenacityBold")) {
                    GradientUtil.applyGradientHorizontal(
                        10f,
                        11f,
                        Fonts.tenacitybold40.getStringWidth("Tomk Max") + 1f,
                        Fonts.tenacitybold40.fontHeight + 1f,
                        1f,
                        clientColors[0],
                        clientColors[1]
                    ) {
                        Fonts.tenacitybold40.drawString("Tomk Max", 11f, 9f, -1, false)
                    }
                }
                else if(nfont.get().equals("Neverlose900")) {
                    GradientUtil.applyGradientHorizontal(
                        10f,
                        10f,
                        Fonts.never900_40.getStringWidth("Tomk Max") + 1f,
                        Fonts.never900_40.fontHeight + 1f,
                        1f,
                        clientColors[0],
                        clientColors[1]
                    ) {
                        Fonts.never900_40.drawString("Tomk Max", 11f, 12f, -1, false)
                    }
                }
                else if(nfont.get().equals("Title")) {
                    GradientUtil.applyGradientHorizontal(
                        10f,
                        10f,
                        Fonts.title40.getStringWidth("Tomk Max") + 1f,
                        Fonts.title40.fontHeight + 1f,
                        1f,
                        clientColors[0],
                        clientColors[1]
                    ) {
                        Fonts.title40.drawString("Tomk Max", 11f, 13f, -1, true)
                    }
                }
                if (nfont.get().equals("TenacityBold")){
                    Fonts.productSans35.drawString("| Reborn | $username | $fps | $servername",Fonts.tenacitybold40.getStringWidth("Tomk Max") + 14f,11f,Color(255,255,255).rgb,true)

                }
                if (nfont.get().equals("Neverlose900")){
                    Fonts.productSans35.drawString("| Reborn | $username | $fps | $servername",Fonts.never900_40.getStringWidth("Tomk Max") + 14f,11f,Color(255,255,255).rgb,true)

                }
                if (nfont.get().equals("Title")){
                    Fonts.productSans35.drawString("| Reborn | $username | $fps | $servername",Fonts.title40.getStringWidth("Tomk Max") + 14f,11f,Color(255,255,255).rgb,true)

                }
            }
            "TomkMax" -> {
                val username = LiquidBounce.USERNAME
                val servername = if (mc2.isSingleplayer) "Singleplayer" else mc2.currentServerData?.serverIP
                val fps = Minecraft.getDebugFPS().toString() + "fps"
                if (!changeValue.get()) {
                    RenderUtils.drawRect(5.0f, 2.5f, Fonts.tenacitybold40.getStringWidth("Tomk Max REBOEN").toFloat() + (Fonts.productSans35.getStringWidth(" | $username | $servername | $fps") + 3.0).toFloat() + 15, 20.0f,Color(0, 0, 0, 180).rgb)
                    RenderUtils.drawShadow(5.0f, 2.5f, Fonts.tenacitybold40.getStringWidth("Tomk Max REBOEN").toFloat() + (Fonts.productSans35.getStringWidth(" | $username | $servername | $fps") + 3.0).toFloat() + 10, 17.5f)
                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 11f, 7f, Color(4, 188, 255).rgb)

                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 10f, 7f, -1)
                    Fonts.productSans35.drawString(" | $username | $servername | $fps", Fonts.tenacitybold40.getStringWidth("Tomk Max REBORN") + 12, 8, -1)
                }
            }
            "Distance" -> {
                val username = LiquidBounce.USERNAME
                val servername = if (mc2.isSingleplayer) "Singleplayer" else mc2.currentServerData?.serverIP
                val fps = Minecraft.getDebugFPS().toString() + "fps"
                val times = dateFormat.format(Date())
                if (!changeValue.get()) {
                    RenderUtils.drawRoundedRect(5.0f, 2.5f, Fonts.tenacitybold40.getStringWidth("Tomk Max REBOEN").toFloat() + (Fonts.fontSFUI35.getStringWidth(" | $username | $servername | $times | $fps") + 3.0).toFloat() + 15, 20.0f,2.5f,Color(30, 30, 30, 200).rgb)
                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 10f, 7f, Color(4, 230, 215).rgb)
                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 10.5f, 7.5f, -1)
                    Fonts.fontSFUI35.drawString(" | $username | $servername | $times | $fps", Fonts.tenacitybold40.getStringWidth("Tomk Max REBORN") + 12, 8, -1)
                }
            }

            "Neverlose" -> {
                val username = LiquidBounce.USERNAME
                val servername = if (mc2.isSingleplayer) "Singleplayer" else mc2.currentServerData?.serverIP
                val fps = Minecraft.getDebugFPS().toString() + "fps"
                val times = dateFormat.format(Date())
                if (!changeValue.get()) {
                    RenderUtils.drawRoundedRect(5.0f, 2.5f, Fonts.tenacitybold40.getStringWidth("Tomk Max REBOEN").toFloat() + (Fonts.productSans35.getStringWidth(" | $username | $servername | $times | $fps") + 3.0).toFloat() + 15, 20.0f,logoradius.get(),Color(0, 0, 0, 110).rgb)
                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 11f, 7f, Color(4, 188, 255).rgb)

                    Fonts.tenacitybold40.drawString("Tomk Max REBORN", 10f, 7f, -1)
                    Fonts.productSans35.drawString(" | $username | $servername | $times | $fps", Fonts.tenacitybold40.getStringWidth("Tomk Max REBORN") + 12, 8, -1)
                }
            }

        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }
    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }

    @EventTarget(ignoreCondition = true)
    fun onScreen(event: ScreenEvent) {
        if (mc.theWorld == null || mc.thePlayer == null) return
        if (state && blurValue.get() && !mc.entityRenderer.isShaderActive() && event.guiScreen != null &&
                !(classProvider.isGuiChat(event.guiScreen) || classProvider.isGuiHudDesigner(event.guiScreen))) mc.entityRenderer.loadShader(classProvider.createResourceLocation("liquidbounce" + "/blur.json")) else if (mc.entityRenderer.shaderGroup != null &&
                mc.entityRenderer.shaderGroup!!.shaderGroupName.contains("liquidbounce/blur.json")) mc.entityRenderer.stopUseShader()
    }

    init {
        state = true
    }
}