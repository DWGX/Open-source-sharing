/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render


import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name="视觉坐标助手", description = "RenderPosHelperSpoofs your ping to a given value.",category = ModuleCategory.RENDER)
class RenderPosHelper : Module() {

    var x1 = FloatValue("x1", 2f, 0f, 100f)
    var x2 = FloatValue("x2", 2f, 0f, 100f)
    var x3 = FloatValue("x3", 2f, 0f, 5f)
    var x4 = FloatValue("x4", 2f, 0f, 100f)
    var x5 = FloatValue("x5", 2f, 1f, 10f)


}