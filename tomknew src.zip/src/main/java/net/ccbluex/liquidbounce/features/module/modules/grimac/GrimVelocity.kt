package net.ccbluex.liquidbounce.features.module.modules.grimac

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.block.BlockSlab
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.CPacketPlayer
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.network.play.server.SPacketExplosion
import net.minecraft.network.play.server.SPacketPlayerPosLook
import net.minecraft.util.EnumFacing
import net.minecraft.util.math.BlockPos


@ModuleInfo(name = "Velocity", description = "onlooker", category = ModuleCategory.COMBAT)
class GrimVelocity : Module() {
    private val sendC03Value = BoolValue("SendC03", true)
    private val fix = BoolValue("Fix Air Ban", true)
    private val breakValue = BoolValue("BreakBlock", true)
    private val alwaysValue = BoolValue("Always", true)
    private val OnlyMove = BoolValue("OnlyMove", false)
    private val OnlyGround = BoolValue("OnlyGround", false)
    private val airfix = BoolValue("Auto Cancel Jump", false)
    private val airTimeValue = IntegerValue("Air Time", 50, 0, 100)
    private var debug = BoolValue("Debug", false)
    private var gotVelo = false
    private var lastWasTeleport = false
    val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
    var airTime: Long = 0
    var currentAirTime: Long = 0

    override fun onEnable() {
        gotVelo = false
        lastWasTeleport = false
    }
    private fun isPlayerOnSlab(player: EntityPlayer): Boolean {
        val playerPos = BlockPos(player.posX, player.posY, player.posZ)

        val block = player.world.getBlockState(playerPos).block
        val boundingBox = player.entityBoundingBox

        return block is BlockSlab && player.posY - playerPos.y <= boundingBox.minY + 0.1
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!mc2.player.onGround && fix.get()) {
            currentAirTime = System.currentTimeMillis() - airTime
        } else if (mc2.player.onGround) {
            currentAirTime = 0
            airTime = System.currentTimeMillis()
        }
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (currentAirTime > (airTimeValue.get() * 10)) {
            return
        }
        if (((OnlyMove.get() && !MovementUtils.isMoving) || (OnlyGround.get() && !mc2.player!!.onGround)) ) {
            return
        }
        val packet = event.packet.unwrap()
        if (packet is SPacketPlayerPosLook) {
            lastWasTeleport = true
            if (debug.get()) {
                val timer = MSTimer()
                if (timer.hasTimePassed(120 * 1000)) {
                    debugMessage("Detected S08")
                    timer.reset()
                }
            }
        }
        if (!lastWasTeleport && packet is SPacketEntityVelocity) {
            if (packet.entityID == mc2.player.entityId) {
                event.cancelEvent()
                gotVelo = true
                if (debug.get()) {
                    val timer = MSTimer()
                    if (timer.hasTimePassed(200 * 1000)) {
                        debugMessage("Cancel S12")
                        timer.reset()
                    }
                }
            }
        }else if (packet is SPacketExplosion) {
            if (packet.motionX != 0f || packet.motionY != 0f || packet.motionZ != 0f) {
                event.cancelEvent()
                gotVelo = true
                if (debug.get()) {
                    val timer = MSTimer()
                    if (timer.hasTimePassed(200 * 1000)) {
                        debugMessage("Cancel S27")
                        timer.reset()
                    }
                }
            }
        }else if (packet.javaClass.name.startsWith("net.minecraft.network.play.server.SPacket")) {
            if (debug.get()) {
                val timer = MSTimer()
                if (timer.hasTimePassed(200 * 10000) && lastWasTeleport) {
                    debugMessage("Detected SPacket")
                    timer.reset()
                }
            }
            lastWasTeleport = false
        }
    }
    @EventTarget
    fun onTick(event: TickEvent?) {
        if (currentAirTime > (airTimeValue.get() * 10)) {
            return
        }
        if (((OnlyMove.get() && !MovementUtils.isMoving) || (OnlyGround.get() && !mc2.player!!.onGround)) ) {
            return
        }
        if (alwaysValue.get() && gotVelo && mc2.player.hurtTime > 0 && !isPlayerOnSlab(mc2.player)) {
            gotVelo = false
            if (sendC03Value.get()) {
                mc2.connection!!.sendPacket(CPacketPlayer(mc2.player.onGround))
                mc2.timer.elapsedPartialTicks -= 20
            }

            val pos = BlockPos(mc2.player.posX, mc2.player.posY + 1.0, mc2.player.posZ)
            if(fix.get() && !mc2.player!!.onGround){
                mc2.connection!!.sendPacket(CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos,EnumFacing.UP))
                if (debug.get()) {
                    val timer1 = MSTimer()
                    if (timer1.hasTimePassed(220 * 1000)) {
                        debugMessage("Air Fix Test")
                        timer1.reset()
                    }
                }
            }else{
                mc2.connection!!.sendPacket(CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.DOWN))
                if (debug.get()) {
                    val timer1 = MSTimer()
                    if (timer1.hasTimePassed(220 * 1000)) {
                        debugMessage("Send C03 and C07")
                        timer1.reset()
                    }
                }
            }
            if (breakValue.get()) {
                mc2.world.setBlockToAir(pos)
            }
        }
    }
    @EventTarget
    fun onJump(event: JumpEvent) {
        if ((killAura.target != null || killAura.currentTarget != null) && (mc2.player.hurtTime > 0 || mc.thePlayer!!.hurtTime > 0)) {
            if (airfix.get()) {
                event.cancelEvent()
            }
        }
    }
    override val tag: String
        get() = "GrimAC"
    fun debugMessage(str: String) {
        if (debug.get()) {
            alert("§7[§c§lVelocity§7] §b$str")
        }
    }
}
