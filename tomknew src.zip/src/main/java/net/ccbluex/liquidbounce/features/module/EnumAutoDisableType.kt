package net.ccbluex.liquidbounce.features.module

object EnumAutoDisableType {

}
