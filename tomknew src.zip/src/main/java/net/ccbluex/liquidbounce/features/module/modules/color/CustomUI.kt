package net.ccbluex.liquidbounce.features.module.modules.color

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue


@ModuleInfo(name = "UISettings", description = "全局视觉渐变调节", category = ModuleCategory.GRIMAC)
class CustomUI : Module() {


    companion object {
        @JvmField
        val r = IntegerValue("Red", 29, 0, 255)
        @JvmField
        val g = IntegerValue("Green", 40, 0, 255)
        @JvmField
        val b = IntegerValue("Blue", 53, 0, 255)
        @JvmField
        val r2= IntegerValue("Red2", 20, 0, 255)
        @JvmField
        val g2= IntegerValue("Green2", 50, 0, 255)
        @JvmField
        val b2 = IntegerValue("Blue2", 80, 0, 255)
        @JvmField
        val a = IntegerValue("Alpha", 255, 0, 255)
        @JvmField
        val radius = FloatValue("Radius", 3f, 0f, 10f)
    }




}
