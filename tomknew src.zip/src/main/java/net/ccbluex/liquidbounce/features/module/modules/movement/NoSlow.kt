/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.enums.WEnumHand
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.inventory.ClickType
import net.minecraft.item.*
import net.minecraft.network.play.client.*
import tomk.utils.packet.PacketUtils

@ModuleInfo(name = "NoSlow", description = "Cancels slowness effects caused by soulsand and using items.",
    category = ModuleCategory.MOVEMENT)
class NoSlow : Module() {

    // Highly customizable values
    private val blockForwardis = FloatValue("BlockForwardis", 1.0F, 0.2F, 1.0F)
    private val blockStrafeis = FloatValue("BlockStrafeis", 1.0F, 0.2F, 1.0F)

    private val consumeForwardis = FloatValue("ConsumeForwardis", 1.0F, 0.2F, 1.0F)
    private val consumeStrafeis = FloatValue("ConsumeStrafeis", 1.0F, 0.2F, 1.0F)

    private val bowForwardis = FloatValue("BowForwardis", 1.0F, 0.2F, 1.0F)
    private val bowStrafeis = FloatValue("BowStrafeis", 1.0F, 0.2F, 1.0F)
    val modeValue = ListValue("Mode", arrayOf("None","Grim","GrimAC","GrimAC2"),"None")
    private val msTimer = MSTimer()
    override fun onDisable() {
        msTimer.reset()
    }

    private val isBlocking: Boolean
        get() = mc2.player.isHandActive && mc.thePlayer!!.heldItem != null && (mc2.player.heldItemMainhand.item is ItemFood || mc2.player.heldItemMainhand.item is ItemPotion || mc2.player.heldItemMainhand.item is ItemBucketMilk || mc2.player.heldItemMainhand.item is ItemSword)


    @EventTarget
    fun onMotion(event: MotionEvent) {
        when(modeValue.get().toLowerCase()){
            "grim" -> {
                if ((mc.thePlayer!!.heldItem == null && mc.thePlayer!!.heldItem?.item == null && mc.thePlayer!!.itemInUse == null && mc.thePlayer!!.itemInUse?.item == null) || mc2.player.heldItemMainhand.item is ItemBlock || !MovementUtils.isMoving) {
                    return
                }

                if (isBlocking && event.eventState == EventState.PRE && mc2.gameSettings.keyBindUseItem.isKeyDown) {
                    PacketUtils.sendPacketNoEvent(
                        CPacketEntityAction(
                            mc2.player,
                            CPacketEntityAction.Action.OPEN_INVENTORY
                        )
                    )

                }
                if (isBlocking && event.eventState == EventState.POST && mc2.gameSettings.keyBindUseItem.isKeyDown) {
                    PacketUtils.sendPacketNoEvent(
                        CPacketClickWindow(
                            mc.thePlayer!!.inventoryContainer.windowId,
                            mc2.player.inventory.currentItem,
                            0,
                            ClickType.QUICK_MOVE,
                            mc.thePlayer!!.heldItem!!.unwrap(),
                            1.toShort()
                        )
                    )

                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.MAIN_HAND))
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.OFF_HAND))
                    mc2.connection!!.sendPacket(CPacketCloseWindow())
                }
            }
            "grimac" -> {


                if(event.eventState == EventState.PRE
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)){
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)))
                }
                if(event.eventState == EventState.POST
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)){
                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.MAIN_HAND))
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.OFF_HAND))
                }




            }
            "grimac2" -> {


                if(event.eventState == EventState.PRE
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)){
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)))
                }
                if(event.eventState == EventState.POST
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)){
                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.MAIN_HAND))
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.OFF_HAND))
                }

                if ((mc.thePlayer!!.heldItem == null && mc.thePlayer!!.heldItem?.item == null && mc.thePlayer!!.itemInUse == null && mc.thePlayer!!.itemInUse?.item == null) || mc2.player.heldItemMainhand.item is ItemBlock || !MovementUtils.isMoving) {
                    return
                }

                if(event.eventState == EventState.PRE
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemFood(mc.thePlayer!!.heldItem!!.item)){
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)))
                }
                if(event.eventState == EventState.POST
                    && mc.thePlayer!!.heldItem!!.item != null
                    && mc.thePlayer!!.isUsingItem
                    && classProvider.isItemFood(mc.thePlayer!!.heldItem!!.item)){
                    mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.MAIN_HAND))
                    mc.netHandler.addToSendQueue(createUseItemPacket(mc.thePlayer!!.heldItem,WEnumHand.OFF_HAND))
                }


            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        val food = mc2.player.heldItemMainhand.item is ItemFood || mc2.player.heldItemMainhand.item is ItemPotion || mc2.player.heldItemMainhand.item is ItemBucketMilk

        when (modeValue.get().toLowerCase()) {
            "grim"->{

                //Post
                if(packet is CPacketAnimation || packet is CPacketPlayerAbilities || packet is CPacketPlayerTryUseItem || packet is CPacketPlayerDigging || packet is CPacketUseEntity || packet is CPacketClickWindow || packet is CPacketEntityAction){
                    PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction())
                }
            }

            "grimac" -> {

                //转头vl
                if (packet is CPacketPlayerTryUseItemOnBlock && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    event.cancelEvent()
                }
                //Post
                if(packet is CPacketAnimation || packet is CPacketPlayerAbilities || packet is CPacketPlayerTryUseItem || packet is CPacketPlayerDigging || packet is CPacketUseEntity || packet is CPacketClickWindow || packet is CPacketEntityAction){
                    PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction())
                }

            }
            "grimac2" -> {


                //Post
                if(packet is CPacketAnimation || packet is CPacketPlayerAbilities || packet is CPacketPlayerTryUseItem || packet is CPacketPlayerDigging || packet is CPacketUseEntity || packet is CPacketClickWindow || packet is CPacketEntityAction){
                    PacketUtils.sendPacketNoEvent(CPacketConfirmTransaction())
                }

            }
        }
    }
    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item

        event.forward = getis(heldItem, true)
        event.strafe = getis(heldItem, false)
    }

    private fun getis(item: IItem?, isForward: Boolean): Float {
        return when {
            classProvider.isItemFood(item) || classProvider.isItemPotion(item) || classProvider.isItemBucketMilk(item) -> {
                if (isForward) this.consumeForwardis.get() else this.consumeStrafeis.get()
            }
            classProvider.isItemSword(item) -> {
                if (isForward) this.blockForwardis.get() else this.blockStrafeis.get()
            }
            classProvider.isItemBow(item) -> {
                if (isForward) this.bowForwardis.get() else this.bowStrafeis.get()
            }
            else -> 0.2F
        }
    }
    override val tag: String
        get() = modeValue.get()
}
