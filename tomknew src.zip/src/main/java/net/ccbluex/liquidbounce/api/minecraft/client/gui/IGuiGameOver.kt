
package net.ccbluex.liquidbounce.api.minecraft.client.gui

interface IGuiGameOver : IGuiScreen {
    val enableButtonsTimer: Int
}