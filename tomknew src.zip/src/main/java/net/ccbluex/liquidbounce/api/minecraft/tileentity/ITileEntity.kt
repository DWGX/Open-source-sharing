
package net.ccbluex.liquidbounce.api.minecraft.tileentity

import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos

interface ITileEntity {
    val pos: WBlockPos
}