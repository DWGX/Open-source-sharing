
package net.ccbluex.liquidbounce.api.minecraft.client.shader

interface IShaderGroup {
    val shaderGroupName: String
}