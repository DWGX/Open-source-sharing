
package net.ccbluex.liquidbounce.api.minecraft.nbt

interface INBTTagDouble : INBTBase