
package net.ccbluex.liquidbounce.api.minecraft.event

interface IClickEvent {
    enum class WAction {
        OPEN_URL
    }
}