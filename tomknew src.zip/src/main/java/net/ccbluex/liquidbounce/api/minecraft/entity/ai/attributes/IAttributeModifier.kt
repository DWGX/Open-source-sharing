
package net.ccbluex.liquidbounce.api.minecraft.entity.ai.attributes

interface IAttributeModifier {
    val amount: Double
}