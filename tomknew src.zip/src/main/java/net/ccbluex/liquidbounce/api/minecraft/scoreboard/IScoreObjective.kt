
package net.ccbluex.liquidbounce.api.minecraft.scoreboard

interface IScoreObjective {
    val displayName: String
    val scoreboard: IScoreboard
}