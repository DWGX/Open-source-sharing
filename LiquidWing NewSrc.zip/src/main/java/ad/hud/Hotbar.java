package ad.hud;

import ad.gui.ui.MusicOverlayRenderer;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.utils.render.ColorManager;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.ScaledResolution;
import org.spongepowered.asm.mixin.Final;

import java.util.List;

public class Hotbar {
    static GuiNewChat guiNewChat = new GuiNewChat(Minecraft.getMinecraft());
    static float width = guiNewChat.getChatWidth();
    @Final
    static List<ChatLine> drawnChatLines;
    public static float x = 0F;
    public static float y = 0F;
    static HUD hud = (HUD) LiquidBounce.moduleManager.getModule(HUD.class);
    public static void render(ScaledResolution sr, int itemX, float partialTicks) {
        if (hud.getColorItem().get()) {
            RenderUtils.drawRect(itemX, sr.getScaledHeight() - 23, itemX + 22, sr.getScaledHeight() - 21, ColorManager.astolfoRainbow(0, 0, 0));
        }
        if (hud.getMusicDisplay().get()) MusicOverlayRenderer.INSTANCE.renderOverlay();
    }
}
