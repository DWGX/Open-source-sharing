/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.other.GrimVelocity
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.SPacketEntityVelocity
import org.lwjgl.input.Keyboard
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@ModuleInfo(name = "Velocity2", description = "Velocity2", Chinese = "击退覆盖2", category = ModuleCategory.COMBAT)
class Velocity2 : Module() {
    val grimVelocity = GrimVelocity()

    val horizontalValue = FloatValue("Horizontal", 0f, -2f, 2f)
    val verticalValue = FloatValue("Vertical", 0f, -2f, 2f)
    val chanceValue = IntegerValue("Chance", 100, 0, 100)
    val velocityTickValue = IntegerValue("VelocityTick", 1, 0, 10)
    val onlyGroundValue = BoolValue("OnlyGround", false)
    val onlyCombatValue = BoolValue("OnlyCombat", false)
    // private val onlyHitVelocityValue = BoolValue("OnlyHitVelocity",false)
    private val noFireValue = BoolValue("noFire", false)

    private val overrideDirectionValue = ListValue("OverrideDirection", arrayOf("None", "Hard", "Offset"), "None")
    private val overrideDirectionYawValue = FloatValue("OverrideDirectionYaw", 0F, -180F, 180F)
        .displayable { !overrideDirectionValue.equals("None") }

    val velocityTimer = MSTimer()
    var wasTimer = false
    var velocityInput = false
    var velocityTick = 0

    var antiDesync = false

    var needReset = true

    override fun onEnable() {
        antiDesync = false
        needReset = true
        grimVelocity.onEnable()
    }

    override fun onDisable() {
        antiDesync = false
        mc.thePlayer!!.capabilities.isFlying = false
        mc.thePlayer!!.noClip = false

        mc.timer.timerSpeed = 1F
        mc.thePlayer!!.speedInAir = 0.02F

        grimVelocity.onDisable()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        grimVelocity.onUpdate(event)
        if (wasTimer) {
            mc.timer.timerSpeed = 1f
            wasTimer = false
        }
        if(velocityInput) {
            velocityTick++
        }else velocityTick = 0

        if (mc.thePlayer!!.isInWater || mc.thePlayer!!.isInLava || mc.thePlayer!!.isInWeb) {
            return
        }

        if ((onlyGroundValue.get() && !mc.thePlayer!!.onGround) || (onlyCombatValue.get() && !LiquidBounce.combatManager.inCombat)) {
            return
        }
        if (noFireValue.get() && mc.thePlayer!!.burning) return
        grimVelocity.onVelocity(event)
    }

    @EventTarget
    fun onMotion(event: MotionEvent) {
        grimVelocity.onMotion(event)
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent){
        grimVelocity.onStrafe(event)
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        grimVelocity.onPacket(event)
        if ((onlyGroundValue.get() && !mc.thePlayer!!.onGround) || (onlyCombatValue.get() && !LiquidBounce.combatManager.inCombat)) {
            return
        }

        val packet = event.packet.unwrap()
        if (packet is SPacketEntityVelocity) {
            if (mc.thePlayer == null || (mc.theWorld?.getEntityByID(packet.entityID) ?: return) != mc.thePlayer) {
                return
            }
            // if(onlyHitVelocityValue.get() && packet.getMotionY()<400.0) return
            if (noFireValue.get() && mc.thePlayer!!.burning) return
            velocityTimer.reset()
            velocityTick = 0

            if (!overrideDirectionValue.equals("None")) {
                val yaw = Math.toRadians(
                    if (overrideDirectionValue.get() == "Hard") {
                        overrideDirectionYawValue.get()
                    } else {
                        mc.thePlayer!!.rotationYaw + overrideDirectionYawValue.get() + 90
                    }.toDouble()
                )
                val dist = sqrt((packet.motionX * packet.motionX + packet.motionZ * packet.motionZ).toDouble())
                val x = cos(yaw) * dist
                val z = sin(yaw) * dist
                packet.motionX = x.toInt()
                packet.motionZ = z.toInt()
            }

            grimVelocity.onVelocityPacket(event)
        }

    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        grimVelocity.onWorld(event)
    }

    @EventTarget
    fun onMove(event: MoveEvent) {
        grimVelocity.onMove(event)
    }

    @EventTarget
    fun onBlockBB(event: BlockBBEvent) {
        grimVelocity.onBlockBB(event)
    }

    @EventTarget
    fun onJump(event: JumpEvent) {
        grimVelocity.onJump(event)
    }

    @EventTarget
    fun onStep(event: StepEvent) {
        grimVelocity.onStep(event)
    }


}
