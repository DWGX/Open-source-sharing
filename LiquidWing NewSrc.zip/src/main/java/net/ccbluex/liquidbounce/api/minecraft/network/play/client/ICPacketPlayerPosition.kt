
package net.ccbluex.liquidbounce.api.minecraft.network.play.client

interface ICPacketPlayerPosition : ICPacketPlayer