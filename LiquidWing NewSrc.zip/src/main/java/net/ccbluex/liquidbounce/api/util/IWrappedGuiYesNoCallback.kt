
package net.ccbluex.liquidbounce.api.util

interface IWrappedGuiYesNoCallback {
    fun confirmClicked(result: Boolean, id: Int)
}