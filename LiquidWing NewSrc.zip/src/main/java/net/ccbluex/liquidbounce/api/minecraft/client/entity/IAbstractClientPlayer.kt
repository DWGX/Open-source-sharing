
package net.ccbluex.liquidbounce.api.minecraft.client.entity

import net.ccbluex.liquidbounce.api.minecraft.client.entity.player.IEntityPlayer

interface IAbstractClientPlayer : IEntityPlayer