package net.ccbluex.liquidbounce.api.minecraft.client.shader

interface IFramebuffer {
    fun bindFramebuffer(b: Boolean)
}