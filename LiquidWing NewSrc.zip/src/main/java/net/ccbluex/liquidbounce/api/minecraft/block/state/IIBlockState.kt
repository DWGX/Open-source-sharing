
package net.ccbluex.liquidbounce.api.minecraft.block.state

import net.ccbluex.liquidbounce.api.minecraft.client.block.IBlock

interface IIBlockState {
    val block: IBlock
}