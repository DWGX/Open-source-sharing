
package net.ccbluex.liquidbounce.api.minecraft.stats

interface IStatBase