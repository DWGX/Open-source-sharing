
package net.ccbluex.liquidbounce.api.minecraft.client.gui

interface IGui