package net.ccbluex.liquidbounce.utils;

import net.minecraft.client.Minecraft;

public class MinecraftInstance2 {
    public static final Minecraft mc = Minecraft.getMinecraft();
}
