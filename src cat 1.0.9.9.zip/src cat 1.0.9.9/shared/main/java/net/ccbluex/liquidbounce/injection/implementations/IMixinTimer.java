package net.ccbluex.liquidbounce.injection.implementations;

public interface IMixinTimer {
    float getTimerSpeed();

    void setTimerSpeed(float timerSpeed);
}
