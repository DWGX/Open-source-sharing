package net.ccbluex.liquidbounce.utils.blur;



import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/*
Copyright Krypton
https://github.com/kkrypt0nn
*/

public class Renderutils2 {
    public static String getHWID() {
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"wmic", "cpu", "get", "ProcessorId"});
            process.getOutputStream().close();
            Scanner sc = new Scanner(process.getInputStream());
            sc.next();
            String serial = sc.next();
            return Renderutils2.getMD5(serial);
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getMD5(String plainText) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes());
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (int offset = 0; offset < digest.length; ++offset) {
                int i = digest[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    sb.append(0);
                }
                sb.append(Integer.toHexString(i));
            }
            return sb.toString().substring(0, 32);
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void setClipboardString() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection trans = new StringSelection(Renderutils2.getHWID());
        clipboard.setContents(trans, null);
    }
}
