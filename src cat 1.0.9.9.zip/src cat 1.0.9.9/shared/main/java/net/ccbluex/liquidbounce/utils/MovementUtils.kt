
package net.ccbluex.liquidbounce.utils

import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity
import net.minecraft.entity.EntityLivingBase
import java.math.BigDecimal
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object MovementUtils : MinecraftInstance() {
    @kotlin.jvm.JvmField
    var bps = 0.0
    private  var lastX:Double = 0.0
    private  var lastY:Double = 0.0
    private  var lastZ:Double = 0.0
    val speed: Float
        get() = sqrt(mc.thePlayer!!.motionX * mc.thePlayer!!.motionX + mc.thePlayer!!.motionZ * mc.thePlayer!!.motionZ).toFloat()

    @JvmStatic
    val isMoving: Boolean
        get() = mc.thePlayer != null && (mc.thePlayer!!.movementInput.moveForward != 0f || mc.thePlayer!!.movementInput.moveStrafe != 0f)

    fun hasMotion(): Boolean {
        return mc.thePlayer!!.motionX != 0.0 && mc.thePlayer!!.motionZ != 0.0 && mc.thePlayer!!.motionY != 0.0
    }

    @JvmStatic
    @JvmOverloads
    fun strafe(speed: Float = this.speed) {
        if (!isMoving) return
        val yaw = direction
        val thePlayer = mc.thePlayer!!
        thePlayer.motionX = -sin(yaw) * speed
        thePlayer.motionZ = cos(yaw) * speed
    }
    @JvmStatic
    fun getScaffoldRotation(yaw: Float, strafe: Float): Float {
        var rotationYaw = yaw
        rotationYaw += 180f
        val forward = -0.5f
        if (strafe < 0f) rotationYaw -= 90f * forward
        if (strafe > 0f) rotationYaw += 90f * forward
        return rotationYaw
    }

    @JvmStatic
    fun forward(length: Double) {
        val thePlayer = mc.thePlayer!!
        val yaw = Math.toRadians(thePlayer.rotationYaw.toDouble())
        thePlayer.setPosition(thePlayer.posX + -sin(yaw) * length, thePlayer.posY, thePlayer.posZ + cos(yaw) * length)
    }
    fun updateBlocksPerSecond() {
        if (mc.thePlayer == null || mc.thePlayer!!.ticksExisted < 1) {
            bps = 0.0
        }
        val distance = mc.thePlayer!!.getDistance(lastX, lastY, lastZ)
        lastX = mc.thePlayer!!.posX
        lastY = mc.thePlayer!!.posY
        lastZ = mc.thePlayer!!.posZ
        bps = distance * (20 * mc.timer.timerSpeed)
    }

    fun getBlockSpeed(entityIn: EntityLivingBase): Double {
        return BigDecimal.valueOf(
            Math.sqrt(
                Math.pow(
                    entityIn.posX - entityIn.prevPosX,
                    2.0
                ) + Math.pow(entityIn.posZ - entityIn.prevPosZ, 2.0)
            ) * 20
        ).setScale(1, BigDecimal.ROUND_HALF_UP).toDouble()
    }
    fun isOnGround(height: Double): Boolean {
        return !mc.theWorld!!.getCollidingBoundingBoxes(
                mc.thePlayer!!,
                mc.thePlayer!!.entityBoundingBox.offset(0.0, -height, 0.0)
            ).isEmpty()
    }

    fun isOnGround(entity: IEntity, height: Double): Boolean {
        return !mc.theWorld!!.getCollidingBoundingBoxes(
                entity,
                entity.entityBoundingBox.offset(0.0, -height, 0.0)
            ).isEmpty()
    }

    @JvmStatic
    val movingYaw: Float
        get() = (direction * 180f / Math.PI).toFloat()

    @JvmStatic
    val direction: Double
        get() {
            val thePlayer = mc.thePlayer!!
            var rotationYaw = thePlayer.rotationYaw
            if (thePlayer.moveForward < 0f) rotationYaw += 180f
            var forward = 1f
            if (thePlayer.moveForward < 0f) forward = -0.5f else if (thePlayer.moveForward > 0f) forward = 0.5f
            if (thePlayer.moveStrafing > 0f) rotationYaw -= 90f * forward
            if (thePlayer.moveStrafing < 0f) rotationYaw += 90f * forward
            return Math.toRadians(rotationYaw.toDouble())
        }
}