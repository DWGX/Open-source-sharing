/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce


import com.sun.jna.Native
import com.sun.jna.Pointer
import me.manager.CombatManager
import net.ccbluex.liquidbounce.api.Wrapper
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.cape.CapeAPI.registerCapeService
import net.ccbluex.liquidbounce.event.ClientShutdownEvent
import net.ccbluex.liquidbounce.event.EventManager
import net.ccbluex.liquidbounce.features.command.CommandManager
import net.ccbluex.liquidbounce.features.macro.MacroManager
import net.ccbluex.liquidbounce.features.module.ModuleManager
import net.ccbluex.liquidbounce.features.special.AntiForge
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof
import net.ccbluex.liquidbounce.features.special.ClientRichPresence
import net.ccbluex.liquidbounce.features.special.DonatorCape
import net.ccbluex.liquidbounce.file.FileManager
import net.ccbluex.liquidbounce.injection.backend.Backend
import net.ccbluex.liquidbounce.script.ScriptManager
import net.ccbluex.liquidbounce.script.remapper.Remapper.loadSrg
import net.ccbluex.liquidbounce.tabs.BlocksTab
import net.ccbluex.liquidbounce.tabs.ExploitsTab
import net.ccbluex.liquidbounce.tabs.HeadsTab
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.client.hud.HUD
import net.ccbluex.liquidbounce.ui.client.hud.HUD.Companion.createDefault
import net.ccbluex.liquidbounce.ui.client.keybind.KeyBindManager
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.ClassUtils.hasForge
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.WebUtils
import net.ccbluex.liquidbounce.utils.misc.sound.TipSoundManager
import net.minecraft.client.gui.GuiScreen
import org.lwjgl.opengl.Display
import java.awt.SystemTray
import java.awt.Toolkit
import java.awt.TrayIcon
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import javax.swing.JOptionPane
import kotlin.concurrent.thread
import kotlin.system.exitProcess

object LiquidBounce {
    // Client information
    const val CLIENT_NAME = "CatBounce"
    const val CLIENT_VERSION = "y-[猫柒团队] 官方群：553849936 Version:1.0.9.9"
    const val CLIENT_VERSIO = "1.0.9.9"
    const val IN_DEV = true
    const val CLIENT_CREATOR = ""
    lateinit var mainMenu: GuiScreen

    const val MINECRAFT_VERSION = Backend.MINECRAFT_VERSION
    const val CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce"
    val UPDATE_LIST = arrayListOf("CatBounce" )

    var isStarting = false

    // Managers
    lateinit var keyBindManager: KeyBindManager
    lateinit var macroManager: MacroManager
    lateinit var moduleManager: ModuleManager
    lateinit var commandManager: CommandManager
    lateinit var eventManager: EventManager

    lateinit var fileManager: FileManager
    lateinit var scriptManager: ScriptManager
    lateinit var combatManager: CombatManager
    lateinit var tipSoundManager: TipSoundManager
    // HUD & ClickGUI
    lateinit var hud: HUD
    private var USERNAME = "Animal"
    lateinit var clickGui: ClickGui

    // Update information
    var latestVersion = 0

    // Menu Background
    var background: IResourceLocation? = null



    // Discord RPC
    lateinit var clientRichPresence: ClientRichPresence

    lateinit var wrapper: Wrapper
    fun setUsername(name : String){
        this.USERNAME = name

    }

    /**
     * Execute if client will be started
     */
    fun startClient() {
       // LiquidBounceKT.verify()
        isStarting = true

        var QQNumber = "qqqdfsa"

        fun displayTray(Title: String, Text: String, type: TrayIcon.MessageType?) {
            val tray = SystemTray.getSystemTray()
            val image = Toolkit.getDefaultToolkit().createImage("Cat.png")
            val trayIcon = TrayIcon(image, "Tray Demo")
            trayIcon.isImageAutoSize = true
            trayIcon.toolTip = "System tray icon demo"
            tray.add(trayIcon)
            trayIcon.displayMessage(Title, Text, type)
        }

        /**
         * 取两个文本之间的文本值
         *
         * @param text  源文本 比如：欲取全文本为 12345
         * @param left  文本前面
         * @param right 后面文本
         * @return 返回 String
         */
        fun getSubString(text: String, left: String?, right: String?): String? {
            var result = ""
            var zLen: Int
            if (left == null || left.isEmpty()) {
                zLen = 0
            } else {
                zLen = text.indexOf(left)
                if (zLen > -1) {
                    zLen += left.length
                } else {
                    zLen = 0
                }
            }
            var yLen = text.indexOf(right!!, zLen)
            if (yLen < 0 || right == null || right.isEmpty()) {
                yLen = text.length
            }
            result = text.substring(zLen, yLen)
            return result
        }

        /****
         * 过滤有效qq窗体信息
         * @param windowText
         * @return 是否为qq窗体信息
         */
        fun _filterQQInfo(windowText: String): Boolean {
            return windowText.startsWith("qqexchangewnd_shortcut_prefix_")
        }

        /******
         * 获取当前登录qq的信息
         * @return map集合
         */
        fun getLoginQQList(): Map<String, String>? {
            val QQNumber1 = arrayOfNulls<String>(1)
            val map: MutableMap<String, String> = HashMap(5)
            val user32 = WebUtils.User32.INSTANCE
            user32.EnumWindows({ hWnd: Pointer, _: Pointer? ->
                val windowText = ByteArray(512)
                user32.GetWindowTextA(hWnd, windowText, 512)
                val wText = Native.toString(windowText)
                if (_filterQQInfo(wText)) {
                    map[hWnd.toString()] = wText.substring(wText.indexOf("qqexchangewnd_shortcut_prefix_") + "qqexchangewnd_shortcut_prefix_".length)
                }
                QQNumber1[0] = getSubString(map.toString(), "=", "}")
                QQNumber = QQNumber1[0].toString()
                true
            }, null)
            return map
        }

        getLoginQQList()
        Display.setTitle("$CLIENT_NAME B$CLIENT_VERSION")
        ClientUtils.getLogger().info("Starting $CLIENT_NAME b$CLIENT_VERSION, by $CLIENT_CREATOR")

        // Create file manager
        fileManager = FileManager()

        // Crate event manager
        eventManager = EventManager()

        // Register listeners
        eventManager.registerListener(RotationUtils())
        eventManager.registerListener(AntiForge())
        eventManager.registerListener(BungeeCordSpoof())
        eventManager.registerListener(DonatorCape())
        eventManager.registerListener(InventoryUtils())


        // Init SoundManager
        tipSoundManager = TipSoundManager()

        // Init Discord RPC
        clientRichPresence = ClientRichPresence()

// KeyBindManager
        keyBindManager = KeyBindManager()
        // Load client fonts
        Fonts.loadFonts()
        net.ccbluex.liquidbounce.feng.FontLoaders. initFonts()

        macroManager = MacroManager()
        eventManager.registerListener(macroManager)
        // Create command manager
        commandManager = CommandManager()

        // Load client fonts
//        Fonts.loadFonts()

        // Setup module manager and register modules
        moduleManager = ModuleManager()
        moduleManager.registerModules()

        try {
            // Remapper
            loadSrg()

            // ScriptManager
            scriptManager = ScriptManager()
            scriptManager.loadScripts()
            scriptManager.enableScripts()
        } catch (throwable: Throwable) {
            ClientUtils.getLogger().error("Failed to load scripts.", throwable)
        }

        // Register commands
        commandManager.registerCommands()

        // Load configs
        fileManager.loadConfigs(fileManager.modulesConfig, fileManager.valuesConfig, fileManager.accountsConfig,
                fileManager.friendsConfig, fileManager.xrayConfig, fileManager.shortcutsConfig)

        // ClickGUI
        clickGui = ClickGui()
        fileManager.loadConfig(fileManager.clickGuiConfig)



        // Tabs (Only for Forge!)
        if (hasForge()) {
            BlocksTab()
            ExploitsTab()
            HeadsTab()
        }

        // Register capes service
        try {
            registerCapeService()
        } catch (throwable: Throwable) {
            ClientUtils.getLogger().error("Failed to register cape service", throwable)
        }

        // Set HUD
        hud = createDefault()
        fileManager.loadConfig(fileManager.hudConfig)

        // Disable optifine fastrender
        ClientUtils.disableFastRender()

        // Load generators
        GuiAltManager.loadGenerators()

        // Setup Discord RPC
        if (clientRichPresence.showRichPresenceValue) {
            thread {
                try {
                    clientRichPresence.setup()
                } catch (throwable: Throwable) {
                    ClientUtils.getLogger().error("Failed to setup Discord RPC.", throwable)
                }
            }
        }

        // Set is starting status
        isStarting = false
    }

    /**
     * Execute if client will be stopped
     */
    fun stopClient() {
        // Call client shutdown
        eventManager.callEvent(ClientShutdownEvent())

        // Save all available configs
        fileManager.saveAllConfigs()

        // Shutdown discord rpc
        clientRichPresence.shutdown()
    }

    private fun readWebPage(url: String?): String {
        var response = ""
        try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val `in` = BufferedReader(InputStreamReader(connection.inputStream))
                val content = StringBuilder()
                var inputLine: String?
                while (`in`.readLine().also { inputLine = it } != null) {
                    content.append(inputLine)
                    content.append("\n")
                }
                `in`.close()
                response = content.toString()
            } else {
                response = "Error: ${connection.responseCode}"
            }
        } catch (e: Exception) {
            response = "Error: ${e.message}"
        }

        return response
    }
}

