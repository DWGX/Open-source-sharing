package cn.hanabi.gui.cloudmusic.api;


public class PlayList {
	public String playListName;
	public String playListId;

	public PlayList(String playListName, String playListId) {
		this.playListName = playListName;
		this.playListId = playListId;
	}
}
