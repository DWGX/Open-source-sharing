package org.example;

import javax.swing.*;
import java.awt.*;

public class WelcomeScreen extends JFrame {

    // 聊天模拟器的代码（与之前的代码相同）
    // ...

    public WelcomeScreen() {
        // 文字弹窗的初始化代码
        setTitle("感谢使用");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        JTextArea welcomeText = new JTextArea("欢迎使用帝王尬笑模拟扣字机！\n本产品无毒无害 不收费 \n娱乐产品如果用作违法用途与作者无关 \n点击“进入”，点击“退出”退出程序。");
        welcomeText.setEditable(false);
        welcomeText.setLineWrap(true);
        welcomeText.setWrapStyleWord(true);
        add(new JScrollPane(welcomeText), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton enterButton = new JButton("进入");
        enterButton.addActionListener(e -> {
            setVisible(false);
            QQChatSimulator chatSimulator = new QQChatSimulator();
            chatSimulator.setVisible(true);
        });
        buttonPanel.add(enterButton);

        JButton exitButton = new JButton("退出");
        exitButton.addActionListener(e -> System.exit(0));
        buttonPanel.add(exitButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    // 聊天模拟器的其他方法（与之前的代码相同）
    // ...

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            welcomeScreen.setVisible(true);
        });
    }
}
