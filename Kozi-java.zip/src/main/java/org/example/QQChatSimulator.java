package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QQChatSimulator extends JFrame {

    private final JTextArea textArea;
    private final JButton startButton;
    private final JButton randomStartButton;
    private final JButton randomStopButton;
    private final JSlider speedSlider;
    private final JCheckBox addRandomPeriodCheckbox;
    private final JCheckBox addRandomExclamationCheckbox;
    private final JCheckBox addRandomCommaCheckbox;
    private final JCheckBox addRandomSpaceCheckbox;

    private final List<String> lines;
    private boolean running;
    private final Random random;
    private int sentenceCounter; // 新增计数器

    public QQChatSimulator() {
        lines = new ArrayList<>();
        running = false;
        random = new Random();
        sentenceCounter = 0; // 初始化计数器为0

        setTitle("模拟训练");
        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        textArea = new JTextArea();
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel optionsPanel = new JPanel(new GridLayout(5, 1));
        addRandomPeriodCheckbox = new JCheckBox("添加随机句号", true);
        optionsPanel.add(addRandomPeriodCheckbox);

        addRandomExclamationCheckbox = new JCheckBox("添加随机叹号", true);
        optionsPanel.add(addRandomExclamationCheckbox);

        addRandomCommaCheckbox = new JCheckBox("添加随机逗号", true);
        optionsPanel.add(addRandomCommaCheckbox);

        addRandomSpaceCheckbox = new JCheckBox("在复制的文本中随机添加空格", true);
        optionsPanel.add(addRandomSpaceCheckbox);

        add(optionsPanel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        startButton = new JButton("正常模拟");
        startButton.addActionListener(e -> {
            if (!running) {
                startSimulation();
            } else {
                stopSimulation();
            }
        });
        buttonPanel.add(startButton);

        randomStartButton = new JButton("双句模拟");
        randomStartButton.addActionListener(e -> {
            if (!running) {
                randomStartSimulation();
            }
        });
        buttonPanel.add(randomStartButton);

        randomStopButton = new JButton("双句结束");
        randomStopButton.addActionListener(e -> stopSimulation());
        buttonPanel.add(randomStopButton);
        randomStopButton.setEnabled(false);

        add(buttonPanel, BorderLayout.SOUTH);

        speedSlider = new JSlider(1, 9, 5);
        speedSlider.setMajorTickSpacing(1);
        speedSlider.setPaintTicks(true);
        speedSlider.setSnapToTicks(true);
        speedSlider.setPaintLabels(true);
        add(speedSlider, BorderLayout.NORTH);

    }


    private void activateProgram(boolean isRunning) {
        if (isRunning) {
            startButton.setText("停止模拟");
            randomStartButton.setEnabled(false);
            randomStopButton.setEnabled(true);
        } else {
            startButton.setText("开始模拟");
            randomStartButton.setEnabled(true);
            randomStopButton.setEnabled(false);
        }
    }

    private void simulateTyping(String text) {
        try {
            StringSelection stringSelection = new StringSelection(text);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);

            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void startSimulation() {
        lines.clear();
        String[] inputLines = textArea.getText().split("\n");
        for (String line : inputLines) {
            if (!line.trim().isEmpty()) {
                lines.add(line);
            }
        }

        if (lines.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入要模拟的文本！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        running = true;
        activateProgram(true);

        Thread simulationThread = new Thread(() -> {
            int minDelay = 100 / speedSlider.getValue();
            int maxDelay = 500 / speedSlider.getValue();

            while (running) {
                String line = lines.get(random.nextInt(lines.size()));
                boolean addPeriod = addRandomPeriodCheckbox.isSelected();
                boolean addExclamation = addRandomExclamationCheckbox.isSelected();
                boolean addComma = addRandomCommaCheckbox.isSelected();
                boolean addSpace = addRandomSpaceCheckbox.isSelected();

                if (addPeriod) {
                    line += (random.nextBoolean() ? "。" : "");
                }

                if (addExclamation) {
                    line += (random.nextBoolean() ? "！" : "");
                }

                if (addComma) {
                    line += (random.nextBoolean() ? "，" : "");
                }

                if (addSpace && sentenceCounter >= 2 && !line.isEmpty()) {
                    // 在模拟的聊天内容后隔2~3句插入一个空格
                    int spaceIndex = random.nextInt(line.length() + 1);
                    line = line.substring(0, spaceIndex) + " " + line.substring(spaceIndex);
                    sentenceCounter = 0; // 重置计数器
                } else {
                    sentenceCounter++;
                }

                simulateTyping(line);

                try {
                    int delay = random.nextInt(maxDelay - minDelay) + minDelay;
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            SwingUtilities.invokeLater(() -> {
                running = false;
                activateProgram(false);
            });
        });
        simulationThread.start();
    }

    public void randomStartSimulation() {
        lines.clear();
        String[] inputLines = textArea.getText().split("\n");
        for (String line : inputLines) {
            if (!line.trim().isEmpty()) {
                lines.add(line);
            }
        }

        if (lines.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入词库文本！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        running = true;
        activateProgram(true);

        Thread randomSimulationThread = new Thread(() -> {
            int minDelay = 100 / speedSlider.getValue();
            int maxDelay = 400 / speedSlider.getValue();

            while (running) {
                String line1 = lines.get(random.nextInt(lines.size()));
                String line2 = lines.get(random.nextInt(lines.size()));
                String combinedLine = line1 + " " + line2;
                boolean addPeriod = addRandomPeriodCheckbox.isSelected();
                boolean addExclamation = addRandomExclamationCheckbox.isSelected();
                boolean addComma = addRandomCommaCheckbox.isSelected();
                boolean addSpace = addRandomSpaceCheckbox.isSelected();

                if (addPeriod) {
                    combinedLine += (random.nextBoolean() ? "。" : "");
                }

                if (addExclamation) {
                    combinedLine += (random.nextBoolean() ? "！" : "");
                }

                if (addComma) {
                    combinedLine += (random.nextBoolean() ? "，" : "");
                }

                if (addSpace && sentenceCounter >= 2) {
                    // 在模拟的聊天内容后隔2~3句插入一个空格
                    int spaceIndex = random.nextInt(combinedLine.length() + 1);
                    combinedLine = combinedLine.substring(0, spaceIndex) + " " + combinedLine.substring(spaceIndex);
                    sentenceCounter = 0; // 重置计数器
                } else {
                    sentenceCounter++;
                }

                simulateTyping(combinedLine);

                try {
                    int delay = random.nextInt(maxDelay - minDelay) + minDelay;
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            SwingUtilities.invokeLater(() -> {
                running = false;
                activateProgram(false);
            });
        });
        randomSimulationThread.start();
    }

    public void stopSimulation() {
        running = false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            QQChatSimulator chatSimulator = new QQChatSimulator();
            chatSimulator.setVisible(true);
        });
    }
}
